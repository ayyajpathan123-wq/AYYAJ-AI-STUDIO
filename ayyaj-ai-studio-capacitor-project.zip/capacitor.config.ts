import type { CapacitorConfig } from '@capacitor/cli';

const serverUrl = process.env.CAPACITOR_SERVER_URL?.trim();

const config: CapacitorConfig = {
  appId: 'com.ayyaj.aistudio',
  appName: 'AYYAJ AI STUDIO',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    ...(serverUrl ? { url: serverUrl, cleartext: false } : {}),
  },
  android: {
    backgroundColor: '#07060B',
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};

export default config;
