export type AppTab = 'home' | 'image' | 'video' | 'creations' | 'history' | 'settings' | 'about';

export type ImageAspectRatio = '1:1' | '16:9' | '9:16' | '4:5';
export type VideoAspectRatio = '16:9' | '9:16';
export type VideoDuration = '3s' | '5s' | '8s' | '10s' | '15s';
export type VideoResolution = '720p' | '1080p';
export type ImageQuality = 'standard' | 'high';

export type ImageStyleId =
  | 'natural'
  | 'cinematic'
  | 'photorealistic'
  | '3d-render'
  | 'anime'
  | 'dark-editorial'
  | 'oil-painting'
  | 'product-studio';

export interface CreationItem {
  id: string;
  type: 'image' | 'video';
  prompt: string;
  negativePrompt?: string;
  style?: ImageStyleId;
  aspectRatio: string;
  duration?: VideoDuration;
  resolution?: VideoResolution;
  model: string;
  dataUrl: string;
  mimeType: string;
  createdAt: number;
  generationMs?: number;
}

export interface DownloadRecord {
  id: string;
  creationId: string;
  type: 'image' | 'video';
  filename: string;
  prompt: string;
  aspectRatio: string;
  downloadedAt: number;
}

export interface StudioSettings {
  defaultImageRatio: ImageAspectRatio;
  defaultImageStyle: ImageStyleId;
  defaultImageQuality: ImageQuality;
  defaultVideoRatio: VideoAspectRatio;
  defaultVideoDuration: VideoDuration;
  defaultVideoResolution: VideoResolution;
  autoSaveCreations: boolean;
  showSplashOnLaunch: boolean;
}

export interface ProviderStatus {
  configured: boolean;
  provider: string;
  imageModels: Array<{ id: string; model: string; label: string }>;
  videoModel: { model: string; label: string };
  capabilities: {
    image: boolean;
    video: boolean;
  };
}
