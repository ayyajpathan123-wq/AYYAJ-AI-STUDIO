/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AboutView } from './components/AboutView';
import { CreationPreviewModal, CreationsView } from './components/CreationsView';
import { DownloadHistoryView } from './components/DownloadHistoryView';
import { HomeView } from './components/HomeView';
import { ImageGeneratorView } from './components/ImageGeneratorView';
import { MobileBottomBar, TopBar } from './components/Navigation';
import { SettingsView } from './components/SettingsView';
import { SplashScreen } from './components/SplashScreen';
import { VideoGeneratorView } from './components/VideoGeneratorView';
import type {
  AppTab,
  CreationItem,
  DownloadRecord,
  ProviderStatus,
  StudioSettings,
} from './types/studio';
import { apiUrl } from './utils/api';
import {
  buildDownloadFilename,
  clearAllStudioData,
  clearDownloadsHistory,
  deleteCreation,
  getAllCreations,
  getAllDownloads,
  loadSettings,
  saveCreation,
  saveDownloadRecord,
  saveSettings,
  triggerFileDownload,
} from './utils/storage';

export default function App() {
  const [settings, setSettings] = useState<StudioSettings>(() => loadSettings());
  const [showSplash, setShowSplash] = useState<boolean>(() => loadSettings().showSplashOnLaunch);
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [providerStatus, setProviderStatus] = useState<ProviderStatus | null>(null);
  const [creations, setCreations] = useState<CreationItem[]>([]);
  const [downloads, setDownloads] = useState<DownloadRecord[]>([]);
  const [reuseImagePrompt, setReuseImagePrompt] = useState<string>('');
  const [reuseVideoPrompt, setReuseVideoPrompt] = useState<string>('');
  const [homePreviewItem, setHomePreviewItem] = useState<CreationItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === message ? null : prev));
    }, 2800);
  }, []);

  useEffect(() => {
    let mounted = true;

    fetch(apiUrl('/api/status'))
      .then((res) => res.json())
      .then((data: ProviderStatus) => {
        if (mounted) setProviderStatus(data);
      })
      .catch(() => {
        if (mounted) {
          setProviderStatus({
            configured: false,
            provider: 'Google Gemini AI',
            imageModels: [],
            videoModel: { model: 'gemini-omni-1.2-flash', label: 'Omni Flash Video' },
            capabilities: { image: false, video: false },
          });
        }
      });

    Promise.all([getAllCreations(), getAllDownloads()]).then(([savedCreations, savedDownloads]) => {
      if (!mounted) return;
      setCreations(savedCreations);
      setDownloads(savedDownloads);
    });

    return () => {
      mounted = false;
    };
  }, []);

  const handleNavigate = useCallback((tab: AppTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleCreationSaved = useCallback(
    async (item: CreationItem) => {
      await saveCreation(item);
      setCreations((prev) => [item, ...prev.filter((c) => c.id !== item.id)]);
      showToast('Saved to My Creations');
    },
    [showToast]
  );

  const handleDownloadAsset = useCallback(
    async (item: CreationItem) => {
      const filename = buildDownloadFilename(item.type, item.prompt, item.mimeType);
      triggerFileDownload(item.dataUrl, filename);

      const record: DownloadRecord = {
        id: crypto.randomUUID(),
        creationId: item.id,
        type: item.type,
        filename,
        prompt: item.prompt,
        aspectRatio: item.aspectRatio,
        downloadedAt: Date.now(),
      };
      await saveDownloadRecord(record);
      setDownloads((prev) => [record, ...prev]);

      // Ensure downloaded item is also saved in library if user had auto-save off
      if (!creations.some((c) => c.id === item.id)) {
        await saveCreation(item);
        setCreations((prev) => [item, ...prev]);
      }

      showToast(`Downloaded ${filename}`);
    },
    [creations, showToast]
  );

  const handleDeleteCreation = useCallback(
    async (id: string) => {
      await deleteCreation(id);
      setCreations((prev) => prev.filter((item) => item.id !== id));
      showToast('Removed creation from library');
    },
    [showToast]
  );

  const handleClearDownloads = useCallback(async () => {
    await clearDownloadsHistory();
    setDownloads([]);
    showToast('Download history cleared');
  }, [showToast]);

  const handleClearAllData = useCallback(async () => {
    await clearAllStudioData();
    setCreations([]);
    setDownloads([]);
    showToast('Local library and history cleared');
  }, [showToast]);

  const handleUpdateSettings = useCallback(
    (next: StudioSettings) => {
      setSettings(next);
      saveSettings(next);
      showToast('Preferences saved');
    },
    [showToast]
  );

  const handleReusePrompt = useCallback(
    (item: CreationItem) => {
      if (item.type === 'video') {
        setReuseVideoPrompt(item.prompt);
        handleNavigate('video');
      } else {
        setReuseImagePrompt(item.prompt);
        handleNavigate('image');
      }
    },
    [handleNavigate]
  );

  return (
    <div className="min-h-dvh bg-[#07060B] text-[#F5F3FF] flex flex-col">
      <AnimatePresence>
        {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      </AnimatePresence>

      <TopBar activeTab={activeTab} onNavigate={handleNavigate} />

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 sm:py-8 pb-24 md:pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeTab === 'home' && (
              <HomeView
                onNavigate={handleNavigate}
                creations={creations}
                downloadsCount={downloads.length}
                providerStatus={providerStatus}
                onSelectCreation={(item) => setHomePreviewItem(item)}
              />
            )}

            {activeTab === 'image' && (
              <ImageGeneratorView
                settings={settings}
                providerStatus={providerStatus}
                initialPrompt={reuseImagePrompt}
                onCreationSaved={handleCreationSaved}
                onDownloadAsset={handleDownloadAsset}
                onOpenSettings={() => handleNavigate('settings')}
              />
            )}

            {activeTab === 'video' && (
              <VideoGeneratorView
                settings={settings}
                providerStatus={providerStatus}
                initialPrompt={reuseVideoPrompt}
                onCreationSaved={handleCreationSaved}
                onDownloadAsset={handleDownloadAsset}
                onOpenSettings={() => handleNavigate('settings')}
              />
            )}

            {activeTab === 'creations' && (
              <CreationsView
                creations={creations}
                onDownloadAsset={handleDownloadAsset}
                onDeleteCreation={handleDeleteCreation}
                onSaveCreation={handleCreationSaved}
                onReusePrompt={handleReusePrompt}
                onNavigateToCreate={(type) => handleNavigate(type)}
              />
            )}

            {activeTab === 'history' && (
              <DownloadHistoryView
                downloads={downloads}
                creations={creations}
                onRedownload={handleDownloadAsset}
                onClearHistory={handleClearDownloads}
                onNotify={showToast}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                providerStatus={providerStatus}
                creationsCount={creations.length}
                downloadsCount={downloads.length}
                onClearAllData={handleClearAllData}
              />
            )}

            {activeTab === 'about' && <AboutView onNavigate={handleNavigate} />}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="hidden md:block border-t border-purple-500/10 py-6">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 text-xs text-zinc-500">
          <span className="font-display font-semibold tracking-wider text-zinc-400">
            AYYAJ AI STUDIO
          </span>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => handleNavigate('about')}
              className="hover:text-zinc-300 transition-colors"
            >
              About Studio
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('settings')}
              className="hover:text-zinc-300 transition-colors"
            >
              Setup &amp; APK Guide
            </button>
          </div>
        </div>
      </footer>

      <MobileBottomBar activeTab={activeTab} onNavigate={handleNavigate} />

      <CreationPreviewModal
        item={homePreviewItem}
        onClose={() => setHomePreviewItem(null)}
        onDownload={handleDownloadAsset}
        onDelete={handleDeleteCreation}
        onSaveNewCreation={handleCreationSaved}
        onReusePrompt={handleReusePrompt}
      />

      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.16 }}
            role="status"
            aria-live="polite"
            className="fixed bottom-20 md:bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-purple-500/35 bg-[#151123]/95 px-4 py-2.5 text-xs font-medium text-white shadow-lg backdrop-blur-md whitespace-nowrap"
          >
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
