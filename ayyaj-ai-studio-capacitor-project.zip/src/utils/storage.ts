import type { CreationItem, DownloadRecord, StudioSettings } from '../types/studio';

const DB_NAME = 'ayyaj-ai-studio-db';
const DB_VERSION = 1;
const CREATIONS_STORE = 'creations';
const DOWNLOADS_STORE = 'downloads';
const SETTINGS_KEY = 'ayyaj_ai_studio_settings_v1';

export const DEFAULT_SETTINGS: StudioSettings = {
  defaultImageRatio: '1:1',
  defaultImageStyle: 'cinematic',
  defaultImageQuality: 'standard',
  defaultVideoRatio: '16:9',
  defaultVideoDuration: '5s',
  defaultVideoResolution: '720p',
  autoSaveCreations: true,
  showSplashOnLaunch: true,
};

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is unavailable in this browser.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(CREATIONS_STORE)) {
        const creationsStore = db.createObjectStore(CREATIONS_STORE, { keyPath: 'id' });
        creationsStore.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains(DOWNLOADS_STORE)) {
        const downloadsStore = db.createObjectStore(DOWNLOADS_STORE, { keyPath: 'id' });
        downloadsStore.createIndex('downloadedAt', 'downloadedAt', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open local studio database.'));
  });
}

export async function getAllCreations(): Promise<CreationItem[]> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(CREATIONS_STORE, 'readonly');
      const store = tx.objectStore(CREATIONS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const items = (req.result as CreationItem[]) || [];
        items.sort((a, b) => b.createdAt - a.createdAt);
        resolve(items);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveCreation(item: CreationItem): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(CREATIONS_STORE, 'readwrite');
    tx.objectStore(CREATIONS_STORE).put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteCreation(id: string): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(CREATIONS_STORE, 'readwrite');
    tx.objectStore(CREATIONS_STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllDownloads(): Promise<DownloadRecord[]> {
  try {
    const db = await openDatabase();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(DOWNLOADS_STORE, 'readonly');
      const req = tx.objectStore(DOWNLOADS_STORE).getAll();
      req.onsuccess = () => {
        const items = (req.result as DownloadRecord[]) || [];
        items.sort((a, b) => b.downloadedAt - a.downloadedAt);
        resolve(items);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveDownloadRecord(record: DownloadRecord): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(DOWNLOADS_STORE, 'readwrite');
    tx.objectStore(DOWNLOADS_STORE).put(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearDownloadsHistory(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(DOWNLOADS_STORE, 'readwrite');
    tx.objectStore(DOWNLOADS_STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllStudioData(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([CREATIONS_STORE, DOWNLOADS_STORE], 'readwrite');
    tx.objectStore(CREATIONS_STORE).clear();
    tx.objectStore(DOWNLOADS_STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export function loadSettings(): StudioSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: StudioSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

export interface RecentPromptEntry {
  text: string;
  usedAt: number;
}

const RECENT_PROMPTS_PREFIX = 'ayyaj_recent_prompts_v1_';
const MAX_RECENT_PROMPTS = 10;

export function loadRecentPrompts(kind: 'image' | 'video'): RecentPromptEntry[] {
  try {
    const raw = localStorage.getItem(`${RECENT_PROMPTS_PREFIX}${kind}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item): item is RecentPromptEntry =>
          Boolean(item) &&
          typeof item === 'object' &&
          typeof (item as RecentPromptEntry).text === 'string' &&
          typeof (item as RecentPromptEntry).usedAt === 'number'
      )
      .slice(0, MAX_RECENT_PROMPTS);
  } catch {
    return [];
  }
}

export function saveRecentPrompt(kind: 'image' | 'video', promptText: string): RecentPromptEntry[] {
  const trimmed = promptText.trim();
  if (!trimmed) return loadRecentPrompts(kind);

  const existing = loadRecentPrompts(kind);
  const next: RecentPromptEntry[] = [
    { text: trimmed, usedAt: Date.now() },
    ...existing.filter((entry) => entry.text !== trimmed),
  ].slice(0, MAX_RECENT_PROMPTS);

  try {
    localStorage.setItem(`${RECENT_PROMPTS_PREFIX}${kind}`, JSON.stringify(next));
  } catch {
    // Ignore storage quota errors
  }
  return next;
}

export function removeRecentPrompt(kind: 'image' | 'video', promptText: string): RecentPromptEntry[] {
  const next = loadRecentPrompts(kind).filter((entry) => entry.text !== promptText);
  try {
    localStorage.setItem(`${RECENT_PROMPTS_PREFIX}${kind}`, JSON.stringify(next));
  } catch {
    // Ignore storage quota errors
  }
  return next;
}

export function clearRecentPrompts(kind: 'image' | 'video'): RecentPromptEntry[] {
  try {
    localStorage.removeItem(`${RECENT_PROMPTS_PREFIX}${kind}`);
  } catch {
    // Ignore storage errors
  }
  return [];
}

export function cropImageDataUrlTo4x5(dataUrl: string): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const targetRatio = 4 / 5;
      const srcWidth = img.naturalWidth;
      const srcHeight = img.naturalHeight;
      const srcRatio = srcWidth / srcHeight;

      let cropWidth = srcWidth;
      let cropHeight = srcHeight;
      let offsetX = 0;
      let offsetY = 0;

      if (srcRatio > targetRatio) {
        cropWidth = Math.round(srcHeight * targetRatio);
        offsetX = Math.round((srcWidth - cropWidth) / 2);
      } else {
        cropHeight = Math.round(srcWidth / targetRatio);
        offsetY = Math.round((srcHeight - cropHeight) / 2);
      }

      const canvas = document.createElement('canvas');
      canvas.width = cropWidth;
      canvas.height = cropHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }
      ctx.drawImage(img, offsetX, offsetY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export interface ImageFilterAdjustments {
  brightness: number; // percentage, default 100
  contrast: number; // percentage, default 100
  saturation: number; // percentage, default 100
  sepia: number; // percentage, default 0
}

export function buildCssFilterString(adj: ImageFilterAdjustments): string {
  return `brightness(${adj.brightness}%) contrast(${adj.contrast}%) saturate(${adj.saturation}%) sepia(${adj.sepia}%)`;
}

export function applyCssFiltersToImageDataUrl(
  dataUrl: string,
  adjustments: ImageFilterAdjustments,
  mimeType = 'image/png'
): Promise<string> {
  if (
    adjustments.brightness === 100 &&
    adjustments.contrast === 100 &&
    adjustments.saturation === 100 &&
    adjustments.sepia === 0
  ) {
    return Promise.resolve(dataUrl);
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }
      ctx.filter = buildCssFilterString(adjustments);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const targetMime = mimeType === 'image/jpeg' ? 'image/jpeg' : 'image/png';
      resolve(canvas.toDataURL(targetMime, 0.95));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export function triggerFileDownload(dataUrl: string, filename: string): void {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function buildDownloadFilename(type: 'image' | 'video', prompt: string, mimeType: string): string {
  const slug = prompt
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32) || 'creation';
  const ext = type === 'video' ? 'mp4' : mimeType.includes('jpeg') ? 'jpg' : 'png';
  const stamp = new Date().toISOString().slice(0, 10);
  return `ayyaj-${slug}-${stamp}.${ext}`;
}
