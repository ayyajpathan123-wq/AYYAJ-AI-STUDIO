import { useEffect } from 'react';
import { motion } from 'motion/react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timer = window.setTimeout(onComplete, prefersReduced ? 650 : 2100);
    return () => window.clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.42, ease: [0.16, 1, 0.3, 1] } }}
      onClick={onComplete}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') onComplete();
      }}
      aria-label="Enter AYYAJ AI STUDIO"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#07060B] px-6 select-none cursor-pointer overflow-hidden"
    >
      {/* Ambient radial purple illumination */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        className="pointer-events-none absolute h-[420px] w-[420px] rounded-full bg-purple-700/20 blur-[110px]"
      />

      {/* Kinetic geometric aperture mark */}
      <motion.div
        initial={{ opacity: 0, scale: 0.84 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="relative mb-8 flex h-20 w-20 items-center justify-center"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 rounded-2xl border border-purple-500/40"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-2 rounded-xl border border-violet-400/25"
        />
        <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-purple-600 to-violet-900 shadow-[0_0_32px_rgba(168,85,247,0.45)]">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            className="h-6 w-6 text-white"
            aria-hidden="true"
          >
            <path
              d="M12 3L20 19H16.2L14.5 15.2H9.5L7.8 19H4L12 3ZM12 8.4L10.4 12.4H13.6L12 8.4Z"
              fill="currentColor"
            />
          </svg>
        </div>
      </motion.div>

      {/* Glowing purple brand title */}
      <motion.h1
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        className="font-display text-center text-3xl sm:text-5xl font-bold tracking-[0.14em] text-white studio-wordmark-glow"
      >
        AYYAJ AI STUDIO
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.32, ease: [0.16, 1, 0.3, 1] }}
        className="mt-3 text-center text-sm tracking-wide text-purple-200/75"
      >
        Image &amp; Video Synthesis Workspace
      </motion.p>

      {/* Smooth loading progress bar */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-8 h-0.5 w-44 overflow-hidden rounded-full bg-purple-950/80"
      >
        <motion.div
          initial={{ x: '-100%' }}
          animate={{ x: '0%' }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
          className="h-full w-full bg-gradient-to-r from-purple-700 via-purple-400 to-violet-300"
        />
      </motion.div>

      <span className="mt-5 text-xs text-purple-300/45">Tap anywhere to continue</span>
    </motion.div>
  );
}
