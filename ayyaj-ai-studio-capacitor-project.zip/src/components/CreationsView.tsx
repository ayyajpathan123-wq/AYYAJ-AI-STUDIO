import { useMemo, useState } from 'react';
import { AnimatePresence } from 'motion/react';
import {
  Download,
  FolderHeart,
  Search,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Video,
  X,
} from 'lucide-react';
import type { CreationItem } from '../types/studio';
import { ImageAdjustmentOverlay } from './ImageAdjustmentOverlay';

interface CreationsViewProps {
  creations: CreationItem[];
  onDownloadAsset: (item: CreationItem) => Promise<void>;
  onDeleteCreation: (id: string) => Promise<void>;
  onSaveCreation: (item: CreationItem) => Promise<void>;
  onReusePrompt: (item: CreationItem) => void;
  onNavigateToCreate: (type: 'image' | 'video') => void;
}

interface CreationPreviewModalProps {
  item: CreationItem | null;
  onClose: () => void;
  onDownload: (item: CreationItem) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onSaveNewCreation: (item: CreationItem) => Promise<void>;
  onReusePrompt: (item: CreationItem) => void;
}

export function CreationPreviewModal({
  item,
  onClose,
  onDownload,
  onDelete,
  onSaveNewCreation,
  onReusePrompt,
}: CreationPreviewModalProps) {
  const [showEditor, setShowEditor] = useState(false);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[90dvh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-purple-500/25 bg-[#100E19]"
      >
        <div className="flex items-center justify-between border-b border-purple-500/15 px-5 py-3.5">
          <div className="text-xs font-medium text-zinc-300">
            <span>{item.type === 'video' ? 'Generated Video' : 'Generated Image'}</span>
            <span aria-hidden="true" className="mx-2 text-zinc-600">·</span>
            <span className="font-mono">{item.aspectRatio}</span>
            {item.duration && (
              <>
                <span aria-hidden="true" className="mx-2 text-zinc-600">·</span>
                <span className="font-mono">{item.duration}</span>
              </>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close preview"
            className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg text-zinc-400 hover:bg-white/10 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <div className="flex max-h-[55dvh] items-center justify-center overflow-hidden rounded-xl bg-[#07060B]">
            {item.type === 'image' ? (
              <img
                src={item.dataUrl}
                alt={item.prompt}
                className="max-h-[55dvh] w-auto object-contain"
              />
            ) : (
              <video
                src={item.dataUrl}
                controls
                playsInline
                autoPlay
                loop
                className="max-h-[55dvh] w-full object-contain"
              />
            )}
          </div>

          <div className="space-y-2">
            <p className="text-sm leading-relaxed text-white">{item.prompt}</p>
            {item.negativePrompt && (
              <p className="text-xs text-zinc-400">Excluded: {item.negativePrompt}</p>
            )}
            <p className="font-mono text-xs text-zinc-500">
              {new Date(item.createdAt).toLocaleString()} · {item.model}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-purple-500/15 px-5 py-3.5">
          <button
            type="button"
            onClick={async () => {
              await onDelete(item.id);
              onClose();
            }}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-red-500/25 px-3.5 py-2 text-xs font-semibold text-red-300 hover:bg-red-500/15 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>Delete</span>
          </button>

          <div className="flex flex-wrap items-center gap-2">
            {item.type === 'image' && (
              <button
                type="button"
                onClick={() => setShowEditor(true)}
                className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-4 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                <SlidersHorizontal className="h-4 w-4" />
                <span>Editor</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                onReusePrompt(item);
                onClose();
              }}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-4 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
            >
              <Sparkles className="h-4 w-4" />
              <span>Reuse Prompt</span>
            </button>
            <button
              type="button"
              onClick={() => onDownload(item)}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-purple-600 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-500 transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showEditor && item.type === 'image' && (
          <div onClick={(e) => e.stopPropagation()}>
            <ImageAdjustmentOverlay
              creation={item}
              alreadySaved={true}
              onClose={() => setShowEditor(false)}
              onSave={async (newCreation) => {
                await onSaveNewCreation(newCreation);
                setShowEditor(false);
                onClose();
              }}
              onDownload={async (adjustedCreation) => {
                await onDownload(adjustedCreation);
                setShowEditor(false);
              }}
            />
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function CreationsView({
  creations,
  onDownloadAsset,
  onDeleteCreation,
  onSaveCreation,
  onReusePrompt,
  onNavigateToCreate,
}: CreationsViewProps) {
  const [filter, setFilter] = useState<'all' | 'image' | 'video'>('all');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<CreationItem | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return creations.filter((item) => {
      if (filter !== 'all' && item.type !== filter) return false;
      if (q && !item.prompt.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [creations, filter, query]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">My Creations</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Browse, preview, download, and manage your saved images and videos stored on this device.
          </p>
        </div>

        {/* Interactive Filter Tabs */}
        <div className="flex items-center gap-1 rounded-xl border border-purple-500/20 bg-[#100E19] p-1 self-start">
          {(['all', 'image', 'video'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`min-h-[36px] rounded-lg px-3.5 py-1.5 text-xs font-medium capitalize transition-colors ${
                filter === tab ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab === 'all' ? `All (${creations.length})` : `${tab}s`}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      {creations.length > 0 && (
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search saved creations by prompt..."
            className="w-full rounded-xl border border-purple-500/15 bg-[#100E19] py-3 pl-10 pr-4 text-sm text-white placeholder:text-zinc-500 focus:border-purple-500 focus:outline-none"
          />
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-purple-500/15 bg-[#100E19] px-6 py-16 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400">
            <FolderHeart className="h-6 w-6" />
          </div>
          <h2 className="mt-4 font-display text-lg font-semibold text-white">
            {creations.length === 0 ? 'No creations saved yet' : 'No matching creations'}
          </h2>
          <p className="mt-1 max-w-sm text-sm text-zinc-400">
            {creations.length === 0
              ? 'Generate your first AI image or video and it will appear here automatically.'
              : 'Try clearing your search query or switching media filters.'}
          </p>
          {creations.length === 0 && (
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button
                type="button"
                onClick={() => onNavigateToCreate('image')}
                className="min-h-[44px] rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-purple-500 transition-colors"
              >
                Create Image
              </button>
              <button
                type="button"
                onClick={() => onNavigateToCreate('video')}
                className="min-h-[44px] rounded-xl border border-purple-500/30 bg-[#161324] px-5 py-2.5 text-xs font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                Create Video
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="group overflow-hidden rounded-2xl border border-purple-500/15 bg-[#100E19] flex flex-col"
            >
              <button
                type="button"
                onClick={() => setSelected(item)}
                className="relative aspect-[4/3] w-full overflow-hidden bg-[#07060B] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-purple-500"
              >
                {item.type === 'image' ? (
                  <img
                    src={item.dataUrl}
                    alt={item.prompt}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <>
                    <video
                      src={item.dataUrl}
                      muted
                      playsInline
                      className="h-full w-full object-cover"
                    />
                    <div className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-lg bg-black/70 text-purple-300">
                      <Video className="h-4 w-4" />
                    </div>
                  </>
                )}
              </button>

              <div className="flex flex-1 flex-col justify-between p-4">
                <div>
                  <p className="line-clamp-2 text-sm font-medium text-white">{item.prompt}</p>
                  <p className="mt-1.5 font-mono text-xs text-zinc-400">
                    {item.type === 'video' ? 'Video' : 'Image'} · {item.aspectRatio}
                    {item.duration ? ` · ${item.duration}` : ''}
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-between gap-2 pt-3 border-t border-purple-500/10">
                  <button
                    type="button"
                    onClick={() => onDownloadAsset(item)}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-purple-600/20 px-3 py-1.5 text-xs font-semibold text-purple-200 hover:bg-purple-600 hover:text-white transition-colors"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Download</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteCreation(item.id)}
                    aria-label="Delete creation"
                    className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg text-zinc-400 hover:bg-red-500/15 hover:text-red-300 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <CreationPreviewModal
        item={selected}
        onClose={() => setSelected(null)}
        onDownload={onDownloadAsset}
        onDelete={onDeleteCreation}
        onSaveNewCreation={onSaveCreation}
        onReusePrompt={onReusePrompt}
      />
    </div>
  );
}
