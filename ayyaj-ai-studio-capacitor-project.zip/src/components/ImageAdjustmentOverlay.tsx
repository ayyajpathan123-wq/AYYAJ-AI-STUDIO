import { useState } from 'react';
import { motion } from 'motion/react';
import { BookmarkPlus, Check, Download, Eye, RotateCcw, SlidersHorizontal, X } from 'lucide-react';
import type { CreationItem } from '../types/studio';
import {
  applyCssFiltersToImageDataUrl,
  buildCssFilterString,
  type ImageFilterAdjustments,
} from '../utils/storage';

interface ImageAdjustmentOverlayProps {
  creation: CreationItem;
  alreadySaved: boolean;
  onClose: (updatedCreation: CreationItem) => void;
  onSave: (newCreation: CreationItem) => Promise<void>;
  onDownload: (adjustedCreation: CreationItem) => Promise<void>;
}

const DEFAULT_FILTERS: ImageFilterAdjustments = {
  brightness: 100,
  contrast: 100,
  saturation: 100,
  sepia: 0,
};

const QUICK_PRESETS: Array<{ label: string; values: ImageFilterAdjustments }> = [
  { label: 'Original', values: { brightness: 100, contrast: 100, saturation: 100, sepia: 0 } },
  { label: 'Vivid', values: { brightness: 105, contrast: 112, saturation: 135, sepia: 0 } },
  { label: 'Moody', values: { brightness: 92, contrast: 122, saturation: 80, sepia: 10 } },
  { label: 'Sepia', values: { brightness: 102, contrast: 108, saturation: 90, sepia: 75 } },
  { label: 'Mono', values: { brightness: 102, contrast: 118, saturation: 0, sepia: 0 } },
];

export function ImageAdjustmentOverlay({
  creation,
  alreadySaved,
  onClose,
  onSave,
  onDownload,
}: ImageAdjustmentOverlayProps) {
  const [filters, setFilters] = useState<ImageFilterAdjustments>(DEFAULT_FILTERS);
  const [compareOriginal, setCompareOriginal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const hasChanges =
    filters.brightness !== 100 ||
    filters.contrast !== 100 ||
    filters.saturation !== 100 ||
    filters.sepia !== 0;

  const activeCssFilter = compareOriginal ? 'none' : buildCssFilterString(filters);

  const buildAdjustedCreation = async (asNewCreation: boolean): Promise<CreationItem> => {
    const bakedDataUrl = await applyCssFiltersToImageDataUrl(
      creation.dataUrl,
      filters,
      creation.mimeType
    );
    return {
      ...creation,
      id: asNewCreation ? crypto.randomUUID() : creation.id,
      createdAt: asNewCreation ? Date.now() : creation.createdAt,
      dataUrl: bakedDataUrl,
    };
  };

  const handleSave = async () => {
    setIsProcessing(true);
    try {
      // Save as a new creation whenever editing an existing saved creation or when filters changed on a saved image
      const shouldMintNewId = alreadySaved;
      const adjusted = await buildAdjustedCreation(shouldMintNewId);
      await onSave(adjusted);
      setSavedNotice(true);
      onClose(adjusted);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = async () => {
    setIsProcessing(true);
    try {
      const shouldMintNewId = alreadySaved && hasChanges;
      const adjusted = await buildAdjustedCreation(shouldMintNewId);
      await onDownload(adjusted);
      setSavedNotice(true);
      onClose(adjusted);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDismiss = async () => {
    if (hasChanges && !alreadySaved) {
      setIsProcessing(true);
      try {
        const adjusted = await buildAdjustedCreation(false);
        onClose(adjusted);
      } finally {
        setIsProcessing(false);
      }
      return;
    }
    onClose(creation);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18 }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="editor-overlay-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 sm:p-6 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 16, scale: 0.98 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="flex max-h-[94dvh] w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl sm:rounded-2xl border border-purple-500/25 bg-[#0F0D18] shadow-[0_24px_80px_rgba(0,0,0,0.75)]"
      >
        {/* Overlay Header */}
        <div className="flex items-center justify-between gap-4 border-b border-purple-500/15 px-5 py-3.5 sm:px-6">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-purple-600/20 text-purple-300">
              <SlidersHorizontal className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <h2
                id="editor-overlay-title"
                className="font-display text-base sm:text-lg font-semibold text-white truncate"
              >
                Image Editor
              </h2>
              <p className="text-xs text-zinc-400 truncate">
                Adjust brightness, contrast, saturation, and sepia in real time
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={isProcessing}
            onClick={handleDismiss}
            aria-label="Close editor overlay"
            className="flex min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-zinc-400 hover:bg-white/10 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Main Workspace: Live Preview + Filter Sliders */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-center">
            {/* Live CSS Filtered Preview */}
            <div className="lg:col-span-7 flex flex-col items-center">
              <div className="relative flex w-full items-center justify-center overflow-hidden rounded-2xl border border-purple-500/20 bg-[#07060B] p-2 sm:p-3">
                <img
                  src={creation.dataUrl}
                  alt={creation.prompt}
                  style={{ filter: activeCssFilter }}
                  className="max-h-[42dvh] sm:max-h-[56dvh] w-auto rounded-xl object-contain transition-[filter] duration-100"
                />

                {hasChanges && (
                  <button
                    type="button"
                    onMouseDown={() => setCompareOriginal(true)}
                    onMouseUp={() => setCompareOriginal(false)}
                    onMouseLeave={() => setCompareOriginal(false)}
                    onTouchStart={() => setCompareOriginal(true)}
                    onTouchEnd={() => setCompareOriginal(false)}
                    onClick={() => setCompareOriginal((prev) => !prev)}
                    className={`absolute bottom-4 right-4 inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold backdrop-blur-md transition-colors ${
                      compareOriginal
                        ? 'bg-purple-600 text-white'
                        : 'bg-black/75 text-zinc-200 border border-white/15 hover:bg-black/90'
                    }`}
                  >
                    <Eye className="h-3.5 w-3.5" />
                    <span>{compareOriginal ? 'Showing Original' : 'Compare Original'}</span>
                  </button>
                )}
              </div>

              <p className="mt-2.5 text-center font-mono text-[11px] text-zinc-400 tabular-nums">
                {creation.aspectRatio} · Brightness {filters.brightness}% · Contrast {filters.contrast}% · Sat {filters.saturation}% · Sepia {filters.sepia}%
              </p>
            </div>

            {/* Adjustment Controls */}
            <div className="lg:col-span-5 space-y-5">
              {/* Quick Presets */}
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-300">Quick Tone Presets</span>
                  <button
                    type="button"
                    disabled={!hasChanges}
                    onClick={() => {
                      setFilters(DEFAULT_FILTERS);
                      setCompareOriginal(false);
                    }}
                    className="inline-flex min-h-[32px] items-center gap-1 text-xs font-medium text-purple-300 hover:text-white disabled:opacity-40 disabled:pointer-events-none transition-colors"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Reset</span>
                  </button>
                </div>

                <div className="mt-2 grid grid-cols-5 gap-1.5">
                  {QUICK_PRESETS.map((preset) => {
                    const isActive =
                      filters.brightness === preset.values.brightness &&
                      filters.contrast === preset.values.contrast &&
                      filters.saturation === preset.values.saturation &&
                      filters.sepia === preset.values.sepia;
                    return (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => {
                          setFilters(preset.values);
                          setCompareOriginal(false);
                        }}
                        className={`min-h-[40px] rounded-xl border px-2 py-1.5 text-[11px] font-medium transition-colors ${
                          isActive
                            ? 'border-purple-500 bg-purple-600/25 text-white'
                            : 'border-purple-500/15 bg-[#0A0911] text-zinc-400 hover:border-purple-500/40 hover:text-white'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Filter Sliders */}
              <div className="rounded-xl border border-purple-500/15 bg-[#0A0911] p-4 space-y-4">
                <div>
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor="slider-brightness" className="font-semibold text-white">
                      Brightness
                    </label>
                    <span className="font-mono text-purple-300 tabular-nums">
                      {filters.brightness}%
                    </span>
                  </div>
                  <input
                    id="slider-brightness"
                    type="range"
                    min={50}
                    max={150}
                    step={1}
                    value={filters.brightness}
                    onChange={(e) => {
                      setCompareOriginal(false);
                      setFilters((prev) => ({ ...prev, brightness: Number(e.target.value) }));
                    }}
                    className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-purple-950 accent-purple-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor="slider-contrast" className="font-semibold text-white">
                      Contrast
                    </label>
                    <span className="font-mono text-purple-300 tabular-nums">
                      {filters.contrast}%
                    </span>
                  </div>
                  <input
                    id="slider-contrast"
                    type="range"
                    min={50}
                    max={150}
                    step={1}
                    value={filters.contrast}
                    onChange={(e) => {
                      setCompareOriginal(false);
                      setFilters((prev) => ({ ...prev, contrast: Number(e.target.value) }));
                    }}
                    className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-purple-950 accent-purple-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor="slider-saturation" className="font-semibold text-white">
                      Saturation
                    </label>
                    <span className="font-mono text-purple-300 tabular-nums">
                      {filters.saturation}%
                    </span>
                  </div>
                  <input
                    id="slider-saturation"
                    type="range"
                    min={0}
                    max={200}
                    step={1}
                    value={filters.saturation}
                    onChange={(e) => {
                      setCompareOriginal(false);
                      setFilters((prev) => ({ ...prev, saturation: Number(e.target.value) }));
                    }}
                    className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-purple-950 accent-purple-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor="slider-sepia" className="font-semibold text-white">
                      Sepia
                    </label>
                    <span className="font-mono text-purple-300 tabular-nums">
                      {filters.sepia}%
                    </span>
                  </div>
                  <input
                    id="slider-sepia"
                    type="range"
                    min={0}
                    max={100}
                    step={1}
                    value={filters.sepia}
                    onChange={(e) => {
                      setCompareOriginal(false);
                      setFilters((prev) => ({ ...prev, sepia: Number(e.target.value) }));
                    }}
                    className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-lg bg-purple-950 accent-purple-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="flex flex-col-reverse gap-2.5 border-t border-purple-500/15 bg-[#0A0911] px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6 pb-safe">
          <button
            type="button"
            disabled={isProcessing}
            onClick={handleDismiss}
            className="min-h-[46px] rounded-xl border border-purple-500/20 px-4 py-2.5 text-xs font-semibold text-zinc-300 hover:bg-white/5 hover:text-white transition-colors"
          >
            {hasChanges && !alreadySaved ? 'Apply to Preview Only' : 'Cancel'}
          </button>

          <div className="grid grid-cols-2 gap-2.5 sm:flex sm:items-center">
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleSave}
              className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-purple-500/35 bg-[#171326] px-4 py-2.5 text-xs sm:text-sm font-semibold text-purple-100 hover:bg-purple-500/20 disabled:opacity-50 transition-colors"
            >
              {savedNotice ? (
                <>
                  <Check className="h-4 w-4 text-emerald-400" />
                  <span>Saved</span>
                </>
              ) : (
                <>
                  <BookmarkPlus className="h-4 w-4" />
                  <span>{alreadySaved ? 'Save as New Creation' : 'Save Creation'}</span>
                </>
              )}
            </button>

            <button
              type="button"
              disabled={isProcessing}
              onClick={handleDownload}
              className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-purple-600 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-[0_0_24px_rgba(147,51,234,0.35)] hover:bg-purple-500 disabled:opacity-50 transition-colors"
            >
              <Download className="h-4 w-4" />
              <span>{isProcessing ? 'Exporting...' : 'Download'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
