import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Download, Film, ImagePlus, RefreshCw, Trash2, Video } from 'lucide-react';
import type {
  CreationItem,
  ProviderStatus,
  StudioSettings,
  VideoAspectRatio,
  VideoDuration,
  VideoResolution,
} from '../types/studio';
import { apiUrl } from '../utils/api';
import {
  clearRecentPrompts,
  loadRecentPrompts,
  removeRecentPrompt,
  saveRecentPrompt,
  type RecentPromptEntry,
} from '../utils/storage';
import { RecentPromptsSidebar } from './RecentPromptsSidebar';

interface VideoGeneratorViewProps {
  settings: StudioSettings;
  providerStatus: ProviderStatus | null;
  initialPrompt?: string;
  onCreationSaved: (item: CreationItem) => Promise<void>;
  onDownloadAsset: (item: CreationItem) => Promise<void>;
  onOpenSettings: () => void;
}

const DURATIONS: VideoDuration[] = ['3s', '5s', '8s', '10s', '15s'];
const VIDEO_RATIOS: Array<{ id: VideoAspectRatio; label: string; hint: string }> = [
  { id: '16:9', label: '16:9', hint: 'Landscape' },
  { id: '9:16', label: '9:16', hint: 'Vertical Reel' },
];
const RESOLUTIONS: VideoResolution[] = ['720p', '1080p'];

const VIDEO_STARTERS = [
  'Slow cinematic dolly shot through a dark obsidian gallery with volumetric violet light beams',
  'Close-up macro of liquid amethyst mercury rippling in zero gravity under dramatic rim light',
];

export function VideoGeneratorView({
  settings,
  providerStatus,
  initialPrompt,
  onCreationSaved,
  onDownloadAsset,
  onOpenSettings,
}: VideoGeneratorViewProps) {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [duration, setDuration] = useState<VideoDuration>(settings.defaultVideoDuration);
  const [aspectRatio, setAspectRatio] = useState<VideoAspectRatio>(settings.defaultVideoRatio);
  const [resolution, setResolution] = useState<VideoResolution>(settings.defaultVideoResolution);
  const [refImage, setRefImage] = useState<{
    previewUrl: string;
    base64: string;
    mimeType: string;
    name: string;
  } | null>(null);

  const [isGenerating, setIsGenerating] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [error, setError] = useState<{ code?: string; message: string } | null>(null);
  const [currentResult, setCurrentResult] = useState<CreationItem | null>(null);
  const [recentPrompts, setRecentPrompts] = useState<RecentPromptEntry[]>(() =>
    loadRecentPrompts('video')
  );

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const pollTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  useEffect(() => {
    return () => {
      if (pollTimerRef.current) {
        window.clearInterval(pollTimerRef.current);
      }
    };
  }, []);

  const handleFileSelected = (file: File | undefined) => {
    if (!file) return;
    const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError({ message: 'Reference image must be a PNG, JPEG, or WebP file.' });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setError({ message: 'Reference image must be smaller than 10 MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || '');
      const commaIdx = dataUrl.indexOf(',');
      if (commaIdx === -1) return;
      setRefImage({
        previewUrl: dataUrl,
        base64: dataUrl.slice(commaIdx + 1),
        mimeType: file.type,
        name: file.name,
      });
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (providerStatus && !providerStatus.configured) {
      setError({
        code: 'API_NOT_CONFIGURED',
        message: 'Video generation requires a connected server-side Gemini API key. Configure GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const trimmed = prompt.trim();
    if (!trimmed) {
      setError({ message: 'Please enter a prompt describing the video scene and motion.' });
      return;
    }

    setRecentPrompts(saveRecentPrompt('video', trimmed));

    if (pollTimerRef.current) {
      window.clearInterval(pollTimerRef.current);
      pollTimerRef.current = null;
    }

    setError(null);
    setIsGenerating(true);
    setElapsedSec(0);

    try {
      const response = await fetch(apiUrl('/api/video/generate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: trimmed,
          duration,
          aspectRatio,
          resolution,
          referenceImage: refImage
            ? { data: refImage.base64, mimeType: refImage.mimeType }
            : undefined,
        }),
      });

      const payload = (await response.json()) as {
        jobId?: string;
        error?: string;
        code?: string;
      };

      if (!response.ok || !payload.jobId) {
        setIsGenerating(false);
        setError({
          code: payload.code,
          message: payload.error || 'Unable to start video generation.',
        });
        return;
      }

      const jobId = payload.jobId;
      const startedAt = Date.now();

      pollTimerRef.current = window.setInterval(async () => {
        setElapsedSec(Math.floor((Date.now() - startedAt) / 1000));
        try {
          const pollRes = await fetch(apiUrl(`/api/video/jobs/${encodeURIComponent(jobId)}`));
          const job = (await pollRes.json()) as {
            status?: 'processing' | 'completed' | 'failed';
            elapsedMs?: number;
            videoDataUrl?: string;
            mimeType?: string;
            error?: string;
            code?: string;
          };

          if (job.status === 'completed' && job.videoDataUrl) {
            if (pollTimerRef.current) {
              window.clearInterval(pollTimerRef.current);
              pollTimerRef.current = null;
            }
            const creation: CreationItem = {
              id: crypto.randomUUID(),
              type: 'video',
              prompt: trimmed,
              aspectRatio,
              duration,
              resolution,
              model: 'gemini-omni-1.2-flash',
              dataUrl: job.videoDataUrl,
              mimeType: job.mimeType || 'video/mp4',
              createdAt: Date.now(),
              generationMs: job.elapsedMs,
            };
            setCurrentResult(creation);
            setIsGenerating(false);
            if (settings.autoSaveCreations) {
              await onCreationSaved(creation);
            }
          } else if (job.status === 'failed' || !pollRes.ok) {
            if (pollTimerRef.current) {
              window.clearInterval(pollTimerRef.current);
              pollTimerRef.current = null;
            }
            setIsGenerating(false);
            setError({
              code: job.code,
              message: job.error || 'Video generation failed on the server.',
            });
          }
        } catch {
          // Keep polling across transient hiccups unless user navigates away
        }
      }, 2000);
    } catch {
      setIsGenerating(false);
      setError({
        message: 'Network error while reaching the studio backend.',
      });
    }
  };

  const isProviderMissing = providerStatus !== null && !providerStatus.configured;
  const previewAspectClass =
    aspectRatio === '9:16' ? 'aspect-[9/16] max-h-[540px] mx-auto' : 'aspect-video';

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">AI Video Generator</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Generate cinematic motion clips from text prompts or animate an uploaded reference frame.
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-purple-500/20 bg-[#100E19] p-1 self-start">
          {RESOLUTIONS.map((resOpt) => (
            <button
              key={resOpt}
              type="button"
              onClick={() => setResolution(resOpt)}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 font-mono text-xs font-medium transition-colors ${
                resolution === resOpt ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {resOpt}
            </button>
          ))}
        </div>
      </div>

      {/* Explicit Setup Notice when Provider Is Not Configured */}
      {isProviderMissing && (
        <div className="rounded-2xl border border-amber-500/35 bg-amber-950/20 p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <h2 className="font-display text-base font-semibold text-amber-200">
                  Video API Setup Required
                </h2>
                <p className="mt-1 text-sm text-amber-100/80">
                  Real AI video generation requires a connected server-side Gemini API key (with billing enabled for Omni Flash Video). No simulated or placeholder videos are generated when disconnected.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenSettings}
              className="min-h-[44px] shrink-0 rounded-xl bg-amber-500/20 border border-amber-400/30 px-4 py-2 text-xs font-semibold text-amber-100 hover:bg-amber-500/30 transition-colors"
            >
              Open API Setup Guide
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
        {/* Left Controls */}
        <div className="space-y-5 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6 lg:col-span-5">
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="video-prompt" className="text-sm font-semibold text-white">
                Motion Prompt
              </label>
              <span className="font-mono text-xs text-zinc-500 tabular-nums">{prompt.length}/1500</span>
            </div>
            <textarea
              id="video-prompt"
              rows={4}
              maxLength={1500}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the scene, subject movement, camera motion, and lighting..."
              className="mt-2 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
            <div className="mt-2.5 flex flex-wrap gap-2">
              {VIDEO_STARTERS.map((starter, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(starter)}
                  className="rounded-lg border border-purple-500/15 bg-[#161324] px-2.5 py-1.5 text-xs text-zinc-300 hover:border-purple-500/40 hover:text-white transition-colors"
                >
                  Motion Idea {idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Optional Reference Image Upload */}
          <div>
            <span className="block text-sm font-semibold text-white">
              Reference Image <span className="text-xs font-normal text-zinc-500">(Optional · Image-to-Video)</span>
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={(e) => handleFileSelected(e.target.files?.[0])}
              className="sr-only"
            />
            {refImage ? (
              <div className="mt-2 flex items-center justify-between gap-3 rounded-xl border border-purple-500/25 bg-[#0A0911] p-3">
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={refImage.previewUrl}
                    alt="Reference frame"
                    className="h-14 w-14 shrink-0 rounded-lg object-cover border border-purple-500/20"
                  />
                  <div className="min-w-0">
                    <p className="truncate text-xs font-medium text-white">{refImage.name}</p>
                    <p className="text-[11px] text-zinc-400">Starting reference frame</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setRefImage(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  aria-label="Remove reference image"
                  className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg text-zinc-400 hover:bg-red-500/15 hover:text-red-300 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-2 flex min-h-[72px] w-full items-center justify-center gap-2.5 rounded-xl border border-dashed border-purple-500/25 bg-[#0A0911] px-4 py-3 text-xs font-medium text-zinc-300 hover:border-purple-500/50 hover:text-white transition-colors"
              >
                <ImagePlus className="h-4 w-4 text-purple-400" />
                <span>Upload PNG, JPG, or WebP reference frame</span>
              </button>
            )}
          </div>

          {/* Duration Selection */}
          <div>
            <span className="block text-sm font-semibold text-white">Video Duration</span>
            <div className="mt-2 grid grid-cols-5 gap-2">
              {DURATIONS.map((dur) => {
                const selected = duration === dur;
                return (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setDuration(dur)}
                    className={`min-h-[44px] rounded-xl border font-mono text-xs font-semibold transition-all ${
                      selected
                        ? 'border-purple-500 bg-purple-600/25 text-white'
                        : 'border-purple-500/15 bg-[#0A0911] text-zinc-400 hover:border-purple-500/35 hover:text-zinc-200'
                    }`}
                  >
                    {dur}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Ratio Selection */}
          <div>
            <span className="block text-sm font-semibold text-white">Aspect Ratio</span>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {VIDEO_RATIOS.map((ratio) => {
                const selected = aspectRatio === ratio.id;
                return (
                  <button
                    key={ratio.id}
                    type="button"
                    onClick={() => setAspectRatio(ratio.id)}
                    className={`flex min-h-[50px] items-center justify-center gap-2 rounded-xl border px-3 py-2 transition-all ${
                      selected
                        ? 'border-purple-500 bg-purple-600/25 text-white'
                        : 'border-purple-500/15 bg-[#0A0911] text-zinc-400 hover:border-purple-500/35 hover:text-zinc-200'
                    }`}
                  >
                    <span className="font-mono text-xs font-semibold">{ratio.label}</span>
                    <span className="text-xs text-zinc-400">· {ratio.hint}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generate CTA */}
          <button
            type="button"
            disabled={isGenerating || isProviderMissing}
            onClick={handleGenerate}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-purple-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_0_24px_rgba(147,51,234,0.35)] hover:bg-purple-500 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.99] transition-all"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Rendering Video ({elapsedSec}s)...</span>
              </>
            ) : isProviderMissing ? (
              <span>Configure AI Provider to Generate</span>
            ) : (
              <>
                <Video className="h-4 w-4" />
                <span>Generate Video</span>
              </>
            )}
          </button>

          {error && (
            <div className="rounded-xl border border-red-500/30 bg-red-950/30 p-3.5 text-xs text-red-200">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="h-4 w-4 shrink-0 text-red-400 mt-0.5" />
                <div className="space-y-2">
                  <p>{error.message}</p>
                  {(error.code === 'API_NOT_CONFIGURED' || error.code === 'QUOTA_OR_BILLING_REQUIRED') && (
                    <button
                      type="button"
                      onClick={onOpenSettings}
                      className="font-semibold text-purple-300 underline hover:text-white"
                    >
                      View Provider &amp; Billing Setup
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Center Video Preview */}
        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6 lg:col-span-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-white">Video Output</h2>
            {currentResult && (
              <span className="font-mono text-xs text-zinc-400 tabular-nums">
                {currentResult.aspectRatio} · {currentResult.duration} · {currentResult.resolution}
              </span>
            )}
          </div>

          <div
            className={`relative flex w-full items-center justify-center overflow-hidden rounded-xl border border-purple-500/15 bg-[#07060B] ${previewAspectClass}`}
          >
            {isGenerating ? (
              <div className="flex w-full max-w-xs flex-col items-center justify-center p-8 text-center">
                <div className="relative h-16 w-16">
                  <div className="absolute inset-0 rounded-full border-2 border-purple-500/20" />
                  <div className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-purple-400" />
                </div>
                <p className="mt-4 font-display text-sm font-semibold text-white">
                  Synthesizing Motion Frames
                </p>
                <p className="mt-1 font-mono text-xs text-purple-300 tabular-nums">
                  {elapsedSec}s elapsed · Video jobs typically take 30–90s
                </p>
                <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-purple-950">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-purple-600 to-violet-400 transition-all duration-500"
                    style={{ width: `${Math.min(92, Math.max(8, elapsedSec * 1.4))}%` }}
                  />
                </div>
              </div>
            ) : currentResult ? (
              <video
                src={currentResult.dataUrl}
                controls
                playsInline
                loop
                autoPlay
                className="h-full w-full object-contain bg-black"
              />
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400">
                  <Film className="h-5 w-5" />
                </div>
                <p className="mt-3 text-sm font-medium text-zinc-300">
                  {isProviderMissing ? 'Provider Setup Required' : 'Ready to render video'}
                </p>
                <p className="mt-1 max-w-xs text-xs text-zinc-500">
                  {isProviderMissing
                    ? 'Connect GEMINI_API_KEY in server secrets to activate Omni Flash video synthesis.'
                    : 'Enter a motion prompt, optionally attach a reference image, and tap Generate Video.'}
                </p>
              </div>
            )}
          </div>

          {currentResult && !isGenerating && (
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onDownloadAsset(currentResult)}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-purple-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-purple-500 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Download MP4</span>
              </button>
              <button
                type="button"
                onClick={handleGenerate}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-4 py-2.5 text-sm font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                <span>Regenerate</span>
              </button>
            </div>
          )}
        </div>

        {/* Right Recent Prompts Sidebar */}
        <div className="lg:col-span-3">
          <RecentPromptsSidebar
            prompts={recentPrompts}
            activePrompt={prompt}
            onSelectPrompt={(text) => setPrompt(text)}
            onRemovePrompt={(text) => setRecentPrompts(removeRecentPrompt('video', text))}
            onClearAll={() => setRecentPrompts(clearRecentPrompts('video'))}
          />
        </div>
      </div>
    </div>
  );
}
