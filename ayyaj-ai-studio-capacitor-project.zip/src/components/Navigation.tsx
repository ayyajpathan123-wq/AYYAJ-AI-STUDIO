import { FolderHeart, History, Home, Image as ImageIcon, Settings, Video } from 'lucide-react';
import type { AppTab } from '../types/studio';

interface NavigationProps {
  activeTab: AppTab;
  onNavigate: (tab: AppTab) => void;
}

const DESKTOP_LINKS: Array<{ id: AppTab; label: string }> = [
  { id: 'home', label: 'Home' },
  { id: 'image', label: 'Image Studio' },
  { id: 'video', label: 'Video Studio' },
  { id: 'creations', label: 'My Creations' },
  { id: 'history', label: 'Downloads' },
];

const MOBILE_TABS: Array<{
  id: AppTab;
  label: string;
  icon: typeof Home;
}> = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'image', label: 'Image', icon: ImageIcon },
  { id: 'video', label: 'Video', icon: Video },
  { id: 'creations', label: 'Creations', icon: FolderHeart },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function TopBar({ activeTab, onNavigate }: NavigationProps) {
  return (
    <header className="sticky top-0 z-40 h-14 md:h-16 border-b border-purple-500/15 bg-[#07060B]/90 backdrop-blur-md pt-safe">
      <div className="mx-auto flex h-full max-w-6xl items-center justify-between gap-8 px-4 sm:px-6">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="font-display text-base sm:text-lg font-bold tracking-[0.08em] text-white studio-wordmark-glow whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 rounded-md px-1"
        >
          AYYAJ AI STUDIO
        </button>

        {/* Zone 2: Clean single-line text nav links (Desktop & Tablet) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium" aria-label="Primary Navigation">
          {DESKTOP_LINKS.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => onNavigate(link.id)}
                className={`relative py-1 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 rounded ${
                  isActive ? 'text-white' : 'text-zinc-400 hover:text-purple-200'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute inset-x-0 -bottom-[19px] h-0.5 bg-purple-500" aria-hidden="true" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('history')}
            aria-label="Download History"
            className={`md:hidden inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 ${
              activeTab === 'history' ? 'text-purple-300 bg-purple-500/15' : 'text-zinc-300 hover:text-white'
            }`}
          >
            <History className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate(activeTab === 'settings' ? 'about' : 'settings')}
            className="inline-flex min-h-[40px] items-center justify-center rounded-lg bg-purple-600 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-500 active:scale-[0.98] transition-all whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
          >
            {activeTab === 'settings' ? 'About Studio' : 'Settings'}
          </button>
        </div>
      </div>
    </header>
  );
}

export function MobileBottomBar({ activeTab, onNavigate }: NavigationProps) {
  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-purple-500/15 bg-[#09080F]/95 backdrop-blur-md pb-safe"
    >
      <div className="grid grid-cols-5 h-16 items-center">
        {MOBILE_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive =
            activeTab === tab.id ||
            (tab.id === 'settings' && activeTab === 'about') ||
            (tab.id === 'creations' && activeTab === 'history');

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onNavigate(tab.id)}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-purple-500 ${
                isActive ? 'text-purple-400' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Icon className="h-5 w-5" strokeWidth={isActive ? 2.25 : 1.75} />
              <span className="text-[11px] font-medium leading-none whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
