import { useEffect, useState } from 'react';
import { AnimatePresence } from 'motion/react';
import {
  AlertCircle,
  BookmarkPlus,
  Check,
  Download,
  Maximize2,
  RefreshCw,
  SlidersHorizontal,
  Sparkles,
  X,
} from 'lucide-react';
import type {
  CreationItem,
  ImageAspectRatio,
  ImageQuality,
  ImageStyleId,
  ProviderStatus,
  StudioSettings,
} from '../types/studio';
import { apiUrl } from '../utils/api';
import {
  clearRecentPrompts,
  cropImageDataUrlTo4x5,
  loadRecentPrompts,
  removeRecentPrompt,
  saveRecentPrompt,
  type RecentPromptEntry,
} from '../utils/storage';
import { ImageAdjustmentOverlay } from './ImageAdjustmentOverlay';
import { RecentPromptsSidebar } from './RecentPromptsSidebar';

interface ImageGeneratorViewProps {
  settings: StudioSettings;
  providerStatus: ProviderStatus | null;
  initialPrompt?: string;
  onCreationSaved: (item: CreationItem) => Promise<void>;
  onDownloadAsset: (item: CreationItem) => Promise<void>;
  onOpenSettings: () => void;
}

const IMAGE_STYLES: Array<{ id: ImageStyleId; label: string }> = [
  { id: 'natural', label: 'Natural' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'photorealistic', label: 'Photorealistic' },
  { id: '3d-render', label: '3D Render' },
  { id: 'anime', label: 'Anime' },
  { id: 'dark-editorial', label: 'Dark Editorial' },
  { id: 'oil-painting', label: 'Oil Painting' },
  { id: 'product-studio', label: 'Product Studio' },
];

const ASPECT_RATIOS: Array<{ id: ImageAspectRatio; label: string; hint: string }> = [
  { id: '1:1', label: '1:1', hint: 'Square' },
  { id: '16:9', label: '16:9', hint: 'Widescreen' },
  { id: '9:16', label: '9:16', hint: 'Mobile Story' },
  { id: '4:5', label: '4:5', hint: 'Portrait' },
];

const STARTER_PROMPTS = [
  'Sculptural matte-black sports coupe parked on rain-slicked basalt under violet dusk lighting',
  'Minimalist luxury fragrance bottle resting on dark slate with amethyst prism caustics',
  'Futuristic architectural atrium crafted from smoked glass and brushed obsidian concrete',
];

export function ImageGeneratorView({
  settings,
  providerStatus,
  initialPrompt,
  onCreationSaved,
  onDownloadAsset,
  onOpenSettings,
}: ImageGeneratorViewProps) {
  const [prompt, setPrompt] = useState(initialPrompt || '');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [style, setStyle] = useState<ImageStyleId>(settings.defaultImageStyle);
  const [aspectRatio, setAspectRatio] = useState<ImageAspectRatio>(settings.defaultImageRatio);
  const [quality, setQuality] = useState<ImageQuality>(settings.defaultImageQuality);
  const [isGenerating, setIsGenerating] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [error, setError] = useState<{ code?: string; message: string } | null>(null);
  const [currentResult, setCurrentResult] = useState<CreationItem | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);
  const [showAdjustmentOverlay, setShowAdjustmentOverlay] = useState(false);
  const [savedIds, setSavedIds] = useState<Record<string, boolean>>({});
  const [recentPrompts, setRecentPrompts] = useState<RecentPromptEntry[]>(() =>
    loadRecentPrompts('image')
  );

  useEffect(() => {
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  useEffect(() => {
    if (!isGenerating) {
      setElapsedSec(0);
      return;
    }
    const started = Date.now();
    const interval = window.setInterval(() => {
      setElapsedSec(Math.floor((Date.now() - started) / 1000));
    }, 250);
    return () => window.clearInterval(interval);
  }, [isGenerating]);

  const handleGenerate = async () => {
    const trimmed = prompt.trim();
    if (!trimmed) {
      setError({ message: 'Please enter a prompt describing the image you want to generate.' });
      return;
    }

    setRecentPrompts(saveRecentPrompt('image', trimmed));
    setError(null);
    setIsGenerating(true);

    try {
      const response = await fetch(apiUrl('/api/image/generate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: trimmed,
          negativePrompt: negativePrompt.trim(),
          style,
          aspectRatio,
          quality,
        }),
      });

      const payload = (await response.json()) as {
        imageDataUrl?: string;
        mimeType?: string;
        model?: string;
        durationMs?: number;
        error?: string;
        code?: string;
      };

      if (!response.ok || !payload.imageDataUrl) {
        setError({
          code: payload.code,
          message: payload.error || 'Image generation failed. Please try again.',
        });
        return;
      }

      const finalDataUrl =
        aspectRatio === '4:5'
          ? await cropImageDataUrlTo4x5(payload.imageDataUrl)
          : payload.imageDataUrl;

      const creation: CreationItem = {
        id: crypto.randomUUID(),
        type: 'image',
        prompt: trimmed,
        negativePrompt: negativePrompt.trim() || undefined,
        style,
        aspectRatio,
        model: payload.model || 'gemini-3.1-flash-lite-image',
        dataUrl: finalDataUrl,
        mimeType: aspectRatio === '4:5' ? 'image/png' : payload.mimeType || 'image/png',
        createdAt: Date.now(),
        generationMs: payload.durationMs,
      };

      setCurrentResult(creation);
      setShowAdjustmentOverlay(true);
    } catch {
      setError({
        message: 'Network error while connecting to the studio server. Please verify the backend is running.',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const previewAspectClass =
    aspectRatio === '16:9'
      ? 'aspect-video'
      : aspectRatio === '9:16'
        ? 'aspect-[9/16] max-h-[540px] mx-auto'
        : aspectRatio === '4:5'
          ? 'aspect-[4/5] max-h-[520px] mx-auto'
          : 'aspect-square';

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">AI Image Generator</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Compose high-resolution imagery with style direction, negative prompts, and custom aspect framing.
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-purple-500/20 bg-[#100E19] p-1 self-start">
          <button
            type="button"
            onClick={() => setQuality('standard')}
            className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              quality === 'standard' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Standard · Fast
          </button>
          <button
            type="button"
            onClick={() => setQuality('high')}
            className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              quality === 'high' ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Pro 2K · Detail
          </button>
        </div>
      </div>

      {providerStatus && !providerStatus.configured && (
        <div className="flex flex-col gap-3 rounded-2xl border border-amber-500/30 bg-amber-950/20 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 shrink-0 text-amber-400 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-amber-200">AI Provider Setup Required</p>
              <p className="mt-0.5 text-xs text-amber-200/80">
                Configure GEMINI_API_KEY in server secrets to run real image generation.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[40px] shrink-0 rounded-lg bg-amber-500/20 px-4 py-2 text-xs font-semibold text-amber-200 hover:bg-amber-500/30 transition-colors"
          >
            View Setup Guide
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
        {/* Left Controls Panel */}
        <div className="space-y-5 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6 lg:col-span-5">
          {/* Prompt */}
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="image-prompt" className="text-sm font-semibold text-white">
                Prompt
              </label>
              <span className="font-mono text-xs text-zinc-500 tabular-nums">{prompt.length}/2000</span>
            </div>
            <textarea
              id="image-prompt"
              rows={4}
              maxLength={2000}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe subject, environment, lighting, camera lens, and mood..."
              className="mt-2 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
            <div className="mt-2.5 flex flex-wrap gap-2">
              {STARTER_PROMPTS.map((starter, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(starter)}
                  className="rounded-lg border border-purple-500/15 bg-[#161324] px-2.5 py-1.5 text-left text-xs text-zinc-300 hover:border-purple-500/40 hover:text-white transition-colors"
                >
                  Idea {idx + 1}
                </button>
              ))}
            </div>
          </div>

          {/* Negative Prompt */}
          <div>
            <label htmlFor="negative-prompt" className="text-sm font-semibold text-white">
              Negative Prompt <span className="text-xs font-normal text-zinc-500">(Optional)</span>
            </label>
            <input
              id="negative-prompt"
              type="text"
              maxLength={800}
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              placeholder="blurry, watermark, distorted hands, oversaturated, text"
              className="mt-2 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-4 py-3 text-sm text-white placeholder:text-zinc-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
            />
          </div>

          {/* Image Style Selection */}
          <div>
            <span className="block text-sm font-semibold text-white">Image Style</span>
            <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {IMAGE_STYLES.map((item) => {
                const selected = style === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setStyle(item.id)}
                    className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-medium transition-all ${
                      selected
                        ? 'border-purple-500 bg-purple-600/25 text-white'
                        : 'border-purple-500/15 bg-[#0A0911] text-zinc-400 hover:border-purple-500/35 hover:text-zinc-200'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Ratio Selection */}
          <div>
            <span className="block text-sm font-semibold text-white">Aspect Ratio</span>
            <div className="mt-2 grid grid-cols-4 gap-2">
              {ASPECT_RATIOS.map((ratio) => {
                const selected = aspectRatio === ratio.id;
                return (
                  <button
                    key={ratio.id}
                    type="button"
                    onClick={() => setAspectRatio(ratio.id)}
                    className={`flex min-h-[52px] flex-col items-center justify-center rounded-xl border px-2 py-2 transition-all ${
                      selected
                        ? 'border-purple-500 bg-purple-600/25 text-white'
                        : 'border-purple-500/15 bg-[#0A0911] text-zinc-400 hover:border-purple-500/35 hover:text-zinc-200'
                    }`}
                  >
                    <span className="font-mono text-xs font-semibold">{ratio.label}</span>
                    <span className="mt-0.5 text-[10px] text-zinc-400">{ratio.hint}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generate CTA */}
          <button
            type="button"
            disabled={isGenerating}
            onClick={handleGenerate}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-purple-600 px-6 py-3 text-sm font-semibold text-white shadow-[0_0_24px_rgba(147,51,234,0.35)] hover:bg-purple-500 disabled:opacity-60 disabled:cursor-not-allowed active:scale-[0.99] transition-all"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Generating ({elapsedSec}s)...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                <span>Generate Image</span>
              </>
            )}
          </button>

          {error && (
            <div className="rounded-xl border border-red-500/30 bg-red-950/30 p-3.5 text-xs text-red-200">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="h-4 w-4 shrink-0 text-red-400 mt-0.5" />
                <div className="space-y-2">
                  <p>{error.message}</p>
                  {(error.code === 'API_NOT_CONFIGURED' || error.code === 'QUOTA_OR_BILLING_REQUIRED') && (
                    <button
                      type="button"
                      onClick={onOpenSettings}
                      className="font-semibold text-purple-300 underline hover:text-white"
                    >
                      Open Provider Setup Guide
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Center Preview Canvas */}
        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6 lg:col-span-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-white">Output Preview</h2>
            {currentResult && (
              <span className="font-mono text-xs text-zinc-400 tabular-nums">
                {currentResult.aspectRatio} · {((currentResult.generationMs || 0) / 1000).toFixed(1)}s
              </span>
            )}
          </div>

          <div
            className={`relative flex w-full items-center justify-center overflow-hidden rounded-xl border border-purple-500/15 bg-[#07060B] ${previewAspectClass}`}
          >
            {isGenerating ? (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <div className="relative h-16 w-16">
                  <div className="absolute inset-0 rounded-full border-2 border-purple-500/20" />
                  <div className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-purple-400" />
                </div>
                <p className="mt-4 font-display text-sm font-semibold text-white">Synthesizing Image</p>
                <p className="mt-1 font-mono text-xs text-purple-300 tabular-nums">{elapsedSec}s elapsed</p>
              </div>
            ) : currentResult ? (
              <>
                <img
                  src={currentResult.dataUrl}
                  alt={currentResult.prompt}
                  className="h-full w-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setIsZoomed(true)}
                  aria-label="Inspect full-screen image"
                  className="absolute right-3 top-3 flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg bg-black/65 text-white backdrop-blur-sm hover:bg-black/85 transition-colors"
                >
                  <Maximize2 className="h-4 w-4" />
                </button>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400">
                  <Sparkles className="h-5 w-5" />
                </div>
                <p className="mt-3 text-sm font-medium text-zinc-300">Ready to render</p>
                <p className="mt-1 max-w-xs text-xs text-zinc-500">
                  Enter a prompt, select your style and aspect ratio, then tap Generate Image.
                </p>
              </div>
            )}
          </div>

          {currentResult && !isGenerating && (
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setShowAdjustmentOverlay(true)}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-3 py-2.5 text-xs sm:text-sm font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                <SlidersHorizontal className="h-4 w-4" />
                <span>Editor</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  await onCreationSaved(currentResult);
                  setSavedIds((prev) => ({ ...prev, [currentResult.id]: true }));
                }}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-3 py-2.5 text-xs sm:text-sm font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                {savedIds[currentResult.id] ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-400" />
                    <span>Saved</span>
                  </>
                ) : (
                  <>
                    <BookmarkPlus className="h-4 w-4" />
                    <span>Save</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await onDownloadAsset(currentResult);
                  setSavedIds((prev) => ({ ...prev, [currentResult.id]: true }));
                }}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-purple-600 px-3 py-2.5 text-xs sm:text-sm font-semibold text-white hover:bg-purple-500 transition-colors"
              >
                <Download className="h-4 w-4" />
                <span>Download</span>
              </button>
              <button
                type="button"
                onClick={handleGenerate}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-purple-500/30 bg-[#161324] px-3 py-2.5 text-xs sm:text-sm font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                <span>Regenerate</span>
              </button>
            </div>
          )}
        </div>

        {/* Right Recent Prompts Sidebar */}
        <div className="lg:col-span-3">
          <RecentPromptsSidebar
            prompts={recentPrompts}
            activePrompt={prompt}
            onSelectPrompt={(text) => setPrompt(text)}
            onRemovePrompt={(text) => setRecentPrompts(removeRecentPrompt('image', text))}
            onClearAll={() => setRecentPrompts(clearRecentPrompts('image'))}
          />
        </div>
      </div>

      {/* Post-Generation CSS Filter Adjustment Overlay */}
      <AnimatePresence>
        {showAdjustmentOverlay && currentResult && (
          <ImageAdjustmentOverlay
            creation={currentResult}
            alreadySaved={Boolean(savedIds[currentResult.id])}
            onClose={async (updatedCreation) => {
              setCurrentResult(updatedCreation);
              setShowAdjustmentOverlay(false);
              if (settings.autoSaveCreations && !savedIds[updatedCreation.id]) {
                await onCreationSaved(updatedCreation);
                setSavedIds((prev) => ({ ...prev, [updatedCreation.id]: true }));
              }
            }}
            onSave={async (adjustedCreation) => {
              setCurrentResult(adjustedCreation);
              await onCreationSaved(adjustedCreation);
              setSavedIds((prev) => ({ ...prev, [adjustedCreation.id]: true }));
            }}
            onDownload={async (adjustedCreation) => {
              setCurrentResult(adjustedCreation);
              await onDownloadAsset(adjustedCreation);
              setSavedIds((prev) => ({ ...prev, [adjustedCreation.id]: true }));
            }}
          />
        )}
      </AnimatePresence>

      {/* Fullscreen Lightbox */}
      {isZoomed && currentResult && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
          onClick={() => setIsZoomed(false)}
        >
          <button
            type="button"
            aria-label="Close preview"
            onClick={() => setIsZoomed(false)}
            className="absolute right-4 top-4 flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={currentResult.dataUrl}
            alt={currentResult.prompt}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[88dvh] max-w-full rounded-xl object-contain"
          />
        </div>
      )}
    </div>
  );
}
