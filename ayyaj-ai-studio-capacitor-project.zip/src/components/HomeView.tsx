import { ArrowUpRight, FolderHeart, History, Image as ImageIcon, Info, Settings, Video } from 'lucide-react';
import { motion } from 'motion/react';
import type { AppTab, CreationItem, ProviderStatus } from '../types/studio';

interface HomeViewProps {
  onNavigate: (tab: AppTab) => void;
  creations: CreationItem[];
  downloadsCount: number;
  providerStatus: ProviderStatus | null;
  onSelectCreation: (item: CreationItem) => void;
}

const IMAGE_ARTWORK = '/src/assets/images/studio_image_generator_1795668346905.jpg';
const VIDEO_ARTWORK = '/src/assets/images/studio_video_generator_1795668347635.jpg';

export function HomeView({
  onNavigate,
  creations,
  downloadsCount,
  providerStatus,
  onSelectCreation,
}: HomeViewProps) {
  const imageCount = creations.filter((c) => c.type === 'image').length;
  const videoCount = creations.filter((c) => c.type === 'video').length;

  return (
    <div className="space-y-8 sm:space-y-10">
      {/* Editorial Studio Header */}
      <section className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div className="max-w-2xl">
          <p className="text-xs font-medium tracking-wide text-purple-300/80">
            AYYAJ AI STUDIO · Creative Synthesis Suite
          </p>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white [text-wrap:balance]">
            Craft high-impact visuals and motion in one studio
          </h1>
        </div>
        <div className="text-xs sm:text-sm text-zinc-400">
          {providerStatus ? (
            <span>
              {providerStatus.configured ? 'AI Engine Ready' : 'API Setup Needed'}
              <span aria-hidden="true" className="mx-2 text-zinc-600">·</span>
              <span className="tabular-nums">{creations.length} Saved</span>
            </span>
          ) : (
            <span>Checking AI engine...</span>
          )}
        </div>
      </section>

      {/* Two Large Commanding Feature Cards */}
      <section aria-label="Core Generators" className="grid grid-cols-1 gap-5 lg:grid-cols-2 lg:gap-6">
        {/* Card 1: AI IMAGE GENERATOR */}
        <motion.button
          type="button"
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.99 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          onClick={() => onNavigate('image')}
          className="group relative flex min-h-[290px] sm:min-h-[340px] w-full flex-col justify-end overflow-hidden rounded-2xl border border-purple-500/20 bg-[#120F1C] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
        >
          {/* Fallback gradient mesh */}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[radial-gradient(circle_at_75%_25%,rgba(147,51,234,0.35),rgba(13,11,20,0.95)_70%)]"
          />
          <img
            src={IMAGE_ARTWORK}
            alt="Sculptural obsidian glass prism artwork for AI Image Generator"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
            className="absolute inset-0 h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-[1.03]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#07060B] via-[#07060B]/65 to-transparent"
          />

          <div className="relative z-10 p-6 sm:p-8">
            <div className="flex items-center justify-between gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-600/25 border border-purple-400/30 text-purple-200">
                <ImageIcon className="h-5 w-5" />
              </div>
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-300 group-hover:text-white transition-colors">
                Launch Studio
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </span>
            </div>

            <h2 className="mt-5 font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              AI IMAGE GENERATOR
            </h2>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-zinc-300">
              Text-to-image synthesis with style direction, negative prompts, and 1:1, 16:9, 9:16, or 4:5 framing.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-zinc-400 tabular-nums">
              <span>8 Art Styles</span>
              <span aria-hidden="true">·</span>
              <span>Up to 2K Detail</span>
              <span aria-hidden="true">·</span>
              <span>{imageCount} Generated</span>
            </div>
          </div>
        </motion.button>

        {/* Card 2: AI VIDEO GENERATOR */}
        <motion.button
          type="button"
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.99 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          onClick={() => onNavigate('video')}
          className="group relative flex min-h-[290px] sm:min-h-[340px] w-full flex-col justify-end overflow-hidden rounded-2xl border border-purple-500/20 bg-[#120F1C] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
        >
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-[radial-gradient(circle_at_30%_25%,rgba(126,34,206,0.38),rgba(13,11,20,0.95)_70%)]"
          />
          <img
            src={VIDEO_ARTWORK}
            alt="Cinema anamorphic camera lens with violet trails for AI Video Generator"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
            className="absolute inset-0 h-full w-full object-cover opacity-85 transition-transform duration-500 group-hover:scale-[1.03]"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#07060B] via-[#07060B]/65 to-transparent"
          />

          <div className="relative z-10 p-6 sm:p-8">
            <div className="flex items-center justify-between gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-600/25 border border-purple-400/30 text-purple-200">
                <Video className="h-5 w-5" />
              </div>
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-300 group-hover:text-white transition-colors">
                Launch Studio
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </span>
            </div>

            <h2 className="mt-5 font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              AI VIDEO GENERATOR
            </h2>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-zinc-300">
              Text-to-video and image-to-video motion synthesis with duration control and MP4 export.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-zinc-400 tabular-nums">
              <span>3s to 15s Clips</span>
              <span aria-hidden="true">·</span>
              <span>Reference Frame</span>
              <span aria-hidden="true">·</span>
              <span>{videoCount} Generated</span>
            </div>
          </div>
        </motion.button>
      </section>

      {/* Secondary Studio Destinations */}
      <section aria-label="Studio Library and Controls">
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          <button
            type="button"
            onClick={() => onNavigate('creations')}
            className="flex min-h-[88px] flex-col justify-between rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:p-5 text-left hover:border-purple-500/35 hover:bg-[#151223] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
          >
            <div className="flex items-center justify-between">
              <FolderHeart className="h-5 w-5 text-purple-400" />
              <span className="font-mono text-xs text-zinc-400 tabular-nums">{creations.length}</span>
            </div>
            <div className="mt-4">
              <div className="font-display text-sm sm:text-base font-semibold text-white">My Creations</div>
              <div className="mt-0.5 text-xs text-zinc-400">Saved images &amp; videos</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="flex min-h-[88px] flex-col justify-between rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:p-5 text-left hover:border-purple-500/35 hover:bg-[#151223] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
          >
            <div className="flex items-center justify-between">
              <History className="h-5 w-5 text-purple-400" />
              <span className="font-mono text-xs text-zinc-400 tabular-nums">{downloadsCount}</span>
            </div>
            <div className="mt-4">
              <div className="font-display text-sm sm:text-base font-semibold text-white">Download History</div>
              <div className="mt-0.5 text-xs text-zinc-400">Exported files log</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="flex min-h-[88px] flex-col justify-between rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:p-5 text-left hover:border-purple-500/35 hover:bg-[#151223] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
          >
            <div className="flex items-center justify-between">
              <Settings className="h-5 w-5 text-purple-400" />
              <span className="text-xs text-zinc-400">Config</span>
            </div>
            <div className="mt-4">
              <div className="font-display text-sm sm:text-base font-semibold text-white">Settings</div>
              <div className="mt-0.5 text-xs text-zinc-400">Defaults, API &amp; APK guide</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('about')}
            className="flex min-h-[88px] flex-col justify-between rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:p-5 text-left hover:border-purple-500/35 hover:bg-[#151223] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
          >
            <div className="flex items-center justify-between">
              <Info className="h-5 w-5 text-purple-400" />
              <span className="text-xs text-zinc-400">Studio</span>
            </div>
            <div className="mt-4">
              <div className="font-display text-sm sm:text-base font-semibold text-white">About AYYAJ AI STUDIO</div>
              <div className="mt-0.5 text-xs text-zinc-400">Architecture &amp; models</div>
            </div>
          </button>
        </div>
      </section>

      {/* Recent Creations Strip */}
      {creations.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-white">Recent Creations</h2>
            <button
              type="button"
              onClick={() => onNavigate('creations')}
              className="text-xs font-medium text-purple-300 hover:text-white transition-colors"
            >
              View all ({creations.length})
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {creations.slice(0, 4).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectCreation(item)}
                className="group relative aspect-square overflow-hidden rounded-xl border border-purple-500/15 bg-[#100E19] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
              >
                {item.type === 'image' ? (
                  <img
                    src={item.dataUrl}
                    alt={item.prompt}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                ) : (
                  <video
                    src={item.dataUrl}
                    muted
                    playsInline
                    className="h-full w-full object-cover"
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent p-3">
                  <p className="truncate text-xs font-medium text-white">{item.prompt}</p>
                  <p className="mt-0.5 text-[11px] text-zinc-300">
                    {item.type === 'video' ? 'Video' : 'Image'} · {item.aspectRatio}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
