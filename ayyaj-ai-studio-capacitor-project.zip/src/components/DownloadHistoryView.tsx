import { useMemo, useState } from 'react';
import JSZip from 'jszip';
import {
  Archive,
  Check,
  Download,
  History,
  Image as ImageIcon,
  RefreshCw,
  Trash2,
  Video,
} from 'lucide-react';
import type { CreationItem, DownloadRecord } from '../types/studio';

interface DownloadHistoryViewProps {
  downloads: DownloadRecord[];
  creations: CreationItem[];
  onRedownload: (item: CreationItem) => Promise<void>;
  onClearHistory: () => Promise<void>;
  onNotify?: (message: string) => void;
}

function makeUniqueArchivePath(
  folder: string,
  filename: string,
  usedPaths: Set<string>
): string {
  const dotIdx = filename.lastIndexOf('.');
  const base = dotIdx > 0 ? filename.slice(0, dotIdx) : filename;
  const ext = dotIdx > 0 ? filename.slice(dotIdx) : '';

  let candidate = `${folder}/${filename}`;
  let counter = 2;
  while (usedPaths.has(candidate)) {
    candidate = `${folder}/${base}-${counter}${ext}`;
    counter += 1;
  }
  usedPaths.add(candidate);
  return candidate;
}

export function DownloadHistoryView({
  downloads,
  creations,
  onRedownload,
  onClearHistory,
  onNotify,
}: DownloadHistoryViewProps) {
  const creationMap = useMemo(
    () => new Map(creations.map((c) => [c.id, c])),
    [creations]
  );

  const exportableRecords = useMemo(
    () => downloads.filter((d) => creationMap.has(d.creationId)),
    [downloads, creationMap]
  );

  const [selectedIds, setSelectedIds] = useState<Set<string>>(() => new Set());
  const [isExportingZip, setIsExportingZip] = useState(false);

  const activeSelectedIds = useMemo(() => {
    const exportableSet = new Set(exportableRecords.map((r) => r.id));
    return new Set([...selectedIds].filter((id) => exportableSet.has(id)));
  }, [selectedIds, exportableRecords]);

  const allSelected =
    exportableRecords.length > 0 && activeSelectedIds.size === exportableRecords.length;

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleToggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(exportableRecords.map((r) => r.id)));
    }
  };

  const handleExportZip = async () => {
    const selectedRecords = exportableRecords.filter((r) => activeSelectedIds.has(r.id));
    if (selectedRecords.length === 0) return;

    setIsExportingZip(true);
    try {
      const zip = new JSZip();
      const usedPaths = new Set<string>();
      const manifestItems: Array<{
        archivePath: string;
        type: 'image' | 'video';
        prompt: string;
        aspectRatio: string;
        model: string;
        downloadedAt: string;
      }> = [];

      for (const record of selectedRecords) {
        const linked = creationMap.get(record.creationId);
        if (!linked?.dataUrl) continue;

        const commaIndex = linked.dataUrl.indexOf(',');
        if (commaIndex === -1) continue;
        const base64Data = linked.dataUrl.slice(commaIndex + 1);
        const folder = record.type === 'video' ? 'videos' : 'images';
        const archivePath = makeUniqueArchivePath(folder, record.filename, usedPaths);

        zip.file(archivePath, base64Data, { base64: true });
        manifestItems.push({
          archivePath,
          type: record.type,
          prompt: record.prompt,
          aspectRatio: record.aspectRatio,
          model: linked.model,
          downloadedAt: new Date(record.downloadedAt).toISOString(),
        });
      }

      if (manifestItems.length === 0) {
        onNotify?.('Selected items have no media data available to export.');
        return;
      }

      zip.file(
        'manifest.json',
        JSON.stringify(
          {
            studio: 'AYYAJ AI STUDIO',
            exportedAt: new Date().toISOString(),
            totalFiles: manifestItems.length,
            items: manifestItems,
          },
          null,
          2
        )
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const blobUrl = URL.createObjectURL(blob);
      const stamp = new Date().toISOString().slice(0, 10);
      const zipFilename = `ayyaj-ai-studio-export-${stamp}.zip`;

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = zipFilename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 2500);

      onNotify?.(`Exported ${manifestItems.length} file${manifestItems.length === 1 ? '' : 's'} to ${zipFilename}`);
    } catch {
      onNotify?.('Failed to build ZIP archive. Please try selecting fewer files.');
    } finally {
      setIsExportingZip(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">Download History</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Track exported images and videos, or select multiple files to export as a ZIP archive.
          </p>
        </div>

        {downloads.length > 0 && (
          <button
            type="button"
            onClick={async () => {
              await onClearHistory();
              setSelectedIds(new Set());
            }}
            className="inline-flex min-h-[42px] items-center gap-2 self-start rounded-xl border border-red-500/25 px-4 py-2 text-xs font-semibold text-red-300 hover:bg-red-500/15 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {downloads.length > 0 && (
        <div className="flex flex-col gap-3 rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={exportableRecords.length === 0}
              onClick={handleToggleSelectAll}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-purple-500/25 bg-[#161324] px-3.5 py-2 text-xs font-semibold text-purple-100 hover:bg-purple-500/20 disabled:opacity-45 disabled:pointer-events-none transition-colors"
            >
              <span
                className={`flex h-4 w-4 items-center justify-center rounded border ${
                  allSelected
                    ? 'border-purple-400 bg-purple-600 text-white'
                    : 'border-zinc-500 bg-transparent'
                }`}
              >
                {allSelected && <Check className="h-3 w-3" strokeWidth={3} />}
              </span>
              <span>{allSelected ? 'Deselect All' : `Select All (${exportableRecords.length})`}</span>
            </button>

            <span className="font-mono text-xs text-zinc-400 tabular-nums">
              {activeSelectedIds.size} selected
            </span>
          </div>

          <button
            type="button"
            disabled={activeSelectedIds.size === 0 || isExportingZip}
            onClick={handleExportZip}
            className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-purple-600 px-5 py-2 text-xs font-semibold text-white shadow-[0_0_20px_rgba(147,51,234,0.3)] hover:bg-purple-500 disabled:opacity-45 disabled:cursor-not-allowed transition-colors"
          >
            {isExportingZip ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Building ZIP...</span>
              </>
            ) : (
              <>
                <Archive className="h-4 w-4" />
                <span>
                  Export ZIP{activeSelectedIds.size > 0 ? ` (${activeSelectedIds.size})` : ''}
                </span>
              </>
            )}
          </button>
        </div>
      )}

      {downloads.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-purple-500/15 bg-[#100E19] px-6 py-16 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400">
            <History className="h-6 w-6" />
          </div>
          <h2 className="mt-4 font-display text-lg font-semibold text-white">No downloads recorded</h2>
          <p className="mt-1 max-w-sm text-sm text-zinc-400">
            When you download a generated image or video, a record will appear here for quick access.
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-purple-500/15 bg-[#100E19]">
          <ul className="divide-y divide-purple-500/10">
            {downloads.map((record) => {
              const linkedCreation = creationMap.get(record.creationId);
              const isSelected = activeSelectedIds.has(record.id);

              return (
                <li
                  key={record.id}
                  className={`flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between sm:px-5 transition-colors ${
                    isSelected ? 'bg-purple-600/10' : ''
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <button
                      type="button"
                      disabled={!linkedCreation}
                      onClick={() => toggleSelect(record.id)}
                      aria-label={
                        linkedCreation
                          ? `Select ${record.filename} for ZIP export`
                          : `${record.filename} unavailable for export`
                      }
                      aria-pressed={isSelected}
                      className="flex min-h-[44px] min-w-[44px] -ml-2 items-center justify-center rounded-xl text-zinc-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500"
                    >
                      <span
                        className={`flex h-5 w-5 items-center justify-center rounded-md border transition-colors ${
                          isSelected
                            ? 'border-purple-400 bg-purple-600 text-white'
                            : 'border-zinc-600 bg-[#08070D]'
                        }`}
                      >
                        {isSelected && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
                      </span>
                    </button>

                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-purple-500/15 text-purple-300 mt-0.5">
                      {record.type === 'video' ? (
                        <Video className="h-5 w-5" />
                      ) : (
                        <ImageIcon className="h-5 w-5" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <p className="truncate font-mono text-xs sm:text-sm font-medium text-white">
                        {record.filename}
                      </p>
                      <p className="mt-0.5 line-clamp-1 text-xs text-zinc-400">{record.prompt}</p>
                      <p className="mt-1 font-mono text-[11px] text-zinc-500 tabular-nums">
                        {record.type.toUpperCase()} · {record.aspectRatio} ·{' '}
                        {new Date(record.downloadedAt).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {linkedCreation ? (
                    <button
                      type="button"
                      onClick={() => onRedownload(linkedCreation)}
                      className="inline-flex min-h-[40px] shrink-0 items-center justify-center gap-1.5 rounded-xl border border-purple-500/30 bg-[#161324] px-3.5 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-600 hover:text-white transition-colors"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download Again</span>
                    </button>
                  ) : (
                    <span className="text-xs text-zinc-500 shrink-0">Removed from library</span>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
