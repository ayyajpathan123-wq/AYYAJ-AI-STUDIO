import { useState } from 'react';
import {
  CheckCircle2,
  Cloud,
  Download,
  RefreshCw,
  Server,
  ShieldCheck,
  Smartphone,
  Trash2,
} from 'lucide-react';
import { apiUrl } from '../utils/api';
import type {
  ImageAspectRatio,
  ImageStyleId,
  ProviderStatus,
  StudioSettings,
  VideoAspectRatio,
  VideoDuration,
} from '../types/studio';

interface SettingsViewProps {
  settings: StudioSettings;
  onUpdateSettings: (next: StudioSettings) => void;
  providerStatus: ProviderStatus | null;
  creationsCount: number;
  downloadsCount: number;
  onClearAllData: () => Promise<void>;
}

type SettingsTab = 'preferences' | 'provider' | 'deployment';

export function SettingsView({
  settings,
  onUpdateSettings,
  providerStatus,
  creationsCount,
  downloadsCount,
  onClearAllData,
}: SettingsViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SettingsTab>('preferences');
  const [confirmClear, setConfirmClear] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const handleDownloadProjectZip = async () => {
    setIsDownloadingZip(true);
    try {
      const res = await fetch(apiUrl('/api/project/export'));
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'ayyaj-ai-studio-capacitor-project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.setTimeout(() => URL.revokeObjectURL(url), 2500);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">Settings</h1>
          <p className="mt-1 text-sm text-zinc-400">
            Configure generation defaults, check server AI status, and view deployment &amp; Android APK guides.
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-xl border border-purple-500/20 bg-[#100E19] p-1 self-start overflow-x-auto max-w-full">
          {(
            [
              { id: 'preferences', label: 'Preferences' },
              { id: 'provider', label: 'AI Provider Setup' },
              { id: 'deployment', label: 'Deploy & Android APK' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                activeSubTab === tab.id ? 'bg-purple-600 text-white' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeSubTab === 'preferences' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Generation Defaults */}
          <div className="space-y-5 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6">
            <h2 className="font-display text-lg font-semibold text-white">Studio Defaults</h2>

            <div className="space-y-4">
              <div>
                <label htmlFor="pref-img-ratio" className="block text-xs font-medium text-zinc-300">
                  Default Image Aspect Ratio
                </label>
                <select
                  id="pref-img-ratio"
                  value={settings.defaultImageRatio}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      defaultImageRatio: e.target.value as ImageAspectRatio,
                    })
                  }
                  className="mt-1.5 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-3.5 py-2.5 text-sm text-white focus:border-purple-500 focus:outline-none"
                >
                  <option value="1:1">1:1 (Square)</option>
                  <option value="16:9">16:9 (Widescreen)</option>
                  <option value="9:16">9:16 (Mobile Story)</option>
                  <option value="4:5">4:5 (Portrait)</option>
                </select>
              </div>

              <div>
                <label htmlFor="pref-img-style" className="block text-xs font-medium text-zinc-300">
                  Default Image Style
                </label>
                <select
                  id="pref-img-style"
                  value={settings.defaultImageStyle}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      defaultImageStyle: e.target.value as ImageStyleId,
                    })
                  }
                  className="mt-1.5 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-3.5 py-2.5 text-sm text-white focus:border-purple-500 focus:outline-none"
                >
                  <option value="natural">Natural</option>
                  <option value="cinematic">Cinematic</option>
                  <option value="photorealistic">Photorealistic</option>
                  <option value="3d-render">3D Render</option>
                  <option value="anime">Anime</option>
                  <option value="dark-editorial">Dark Editorial</option>
                  <option value="oil-painting">Oil Painting</option>
                  <option value="product-studio">Product Studio</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="pref-vid-dur" className="block text-xs font-medium text-zinc-300">
                    Default Video Duration
                  </label>
                  <select
                    id="pref-vid-dur"
                    value={settings.defaultVideoDuration}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        defaultVideoDuration: e.target.value as VideoDuration,
                      })
                    }
                    className="mt-1.5 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-3.5 py-2.5 text-sm text-white focus:border-purple-500 focus:outline-none"
                  >
                    <option value="3s">3s</option>
                    <option value="5s">5s</option>
                    <option value="8s">8s</option>
                    <option value="10s">10s</option>
                    <option value="15s">15s</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="pref-vid-ratio" className="block text-xs font-medium text-zinc-300">
                    Default Video Ratio
                  </label>
                  <select
                    id="pref-vid-ratio"
                    value={settings.defaultVideoRatio}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        defaultVideoRatio: e.target.value as VideoAspectRatio,
                      })
                    }
                    className="mt-1.5 w-full rounded-xl border border-purple-500/20 bg-[#08070D] px-3.5 py-2.5 text-sm text-white focus:border-purple-500 focus:outline-none"
                  >
                    <option value="16:9">16:9 (Landscape)</option>
                    <option value="9:16">9:16 (Vertical)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* App Behavior & Local Storage */}
          <div className="space-y-5 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6">
            <h2 className="font-display text-lg font-semibold text-white">App &amp; Local Storage</h2>

            <div className="space-y-4">
              <label className="flex items-center justify-between gap-4 rounded-xl border border-purple-500/15 bg-[#0A0911] p-4 cursor-pointer">
                <div>
                  <div className="text-sm font-medium text-white">Auto-save Creations</div>
                  <div className="text-xs text-zinc-400">
                    Save generated images and videos to My Creations automatically.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoSaveCreations}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, autoSaveCreations: e.target.checked })
                  }
                  className="h-5 w-5 accent-purple-600"
                />
              </label>

              <label className="flex items-center justify-between gap-4 rounded-xl border border-purple-500/15 bg-[#0A0911] p-4 cursor-pointer">
                <div>
                  <div className="text-sm font-medium text-white">Animated Splash on Launch</div>
                  <div className="text-xs text-zinc-400">
                    Show the glowing AYYAJ AI STUDIO intro animation when opening the app.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showSplashOnLaunch}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, showSplashOnLaunch: e.target.checked })
                  }
                  className="h-5 w-5 accent-purple-600"
                />
              </label>

              <div className="rounded-xl border border-purple-500/15 bg-[#0A0911] p-4">
                <div className="flex items-center justify-between text-xs text-zinc-400 tabular-nums">
                  <span>Saved Creations: {creationsCount}</span>
                  <span>Download Records: {downloadsCount}</span>
                </div>
                {!confirmClear ? (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="mt-3 inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-red-500/25 px-4 py-2 text-xs font-semibold text-red-300 hover:bg-red-500/15 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                    <span>Clear Local Creations &amp; History</span>
                  </button>
                ) : (
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        await onClearAllData();
                        setConfirmClear(false);
                      }}
                      className="min-h-[40px] rounded-xl bg-red-600 px-4 py-2 text-xs font-semibold text-white hover:bg-red-500"
                    >
                      Confirm Erase All
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="min-h-[40px] rounded-xl border border-purple-500/20 px-4 py-2 text-xs font-semibold text-zinc-300 hover:bg-white/5"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'provider' && (
        <div className="space-y-5 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-purple-500/10 pb-4">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-600/20 text-purple-300">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-display text-lg font-semibold text-white">
                  Server-Side AI Provider Status
                </h2>
                <p className="text-xs text-zinc-400">
                  Credentials are isolated exclusively on the Express backend and never bundled in frontend code.
                </p>
              </div>
            </div>
            <div className="text-xs font-semibold">
              {providerStatus?.configured ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  Connected via Server Secret
                </span>
              ) : (
                <span className="text-amber-300">Requires Server Secret Setup</span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-purple-500/15 bg-[#0A0911] p-4 space-y-2">
              <h3 className="font-display text-sm font-semibold text-white">
                1. Configure in Google AI Studio
              </h3>
              <ol className="list-decimal list-inside space-y-1.5 text-xs leading-relaxed text-zinc-300">
                <li>Open Settings &rarr; Secrets in your AI Studio workspace.</li>
                <li>Select or attach a billing-enabled key for <code className="font-mono text-purple-300">GEMINI_API_KEY</code>.</li>
                <li>Restart or reload the preview so the backend reads the updated environment secret.</li>
              </ol>
            </div>

            <div className="rounded-xl border border-purple-500/15 bg-[#0A0911] p-4 space-y-2">
              <h3 className="font-display text-sm font-semibold text-white">
                2. Configure on Self-Hosted / Cloud Server
              </h3>
              <p className="text-xs leading-relaxed text-zinc-300">
                Set the environment variable on your server host (never prefix with <code className="font-mono text-purple-300">VITE_</code>):
              </p>
              <pre className="overflow-x-auto rounded-lg bg-[#07060B] p-3 font-mono text-xs text-purple-200 border border-purple-500/15">
{`GEMINI_API_KEY=your_server_api_key
PORT=3000`}
              </pre>
            </div>
          </div>

          <div className="rounded-xl border border-purple-500/15 bg-[#0A0911] p-4">
            <h3 className="font-display text-sm font-semibold text-white">Connected Generation Engines</h3>
            <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3 text-xs">
              <div className="rounded-lg bg-[#07060B] p-3 border border-purple-500/10">
                <div className="text-zinc-400">Image (Standard)</div>
                <div className="mt-1 font-mono text-purple-200">gemini-3.1-flash-lite-image</div>
              </div>
              <div className="rounded-lg bg-[#07060B] p-3 border border-purple-500/10">
                <div className="text-zinc-400">Image (Pro 2K)</div>
                <div className="mt-1 font-mono text-purple-200">gemini-nano-banana-2.1</div>
              </div>
              <div className="rounded-lg bg-[#07060B] p-3 border border-purple-500/10">
                <div className="text-zinc-400">Video Synthesis</div>
                <div className="mt-1 font-mono text-purple-200">gemini-omni-1.2-flash</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'deployment' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Production Deployment Guide */}
          <div className="space-y-4 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-600/20 text-purple-300">
                <Cloud className="h-5 w-5" />
              </div>
              <div>
                <h2 className="font-display text-lg font-semibold text-white">Production Deployment Guide</h2>
                <p className="text-xs text-zinc-400">Full-stack Express + Vite build</p>
              </div>
            </div>

            <ol className="list-decimal list-inside space-y-2.5 text-xs leading-relaxed text-zinc-300">
              <li>
                Install dependencies: <code className="font-mono text-purple-300">npm install</code>
              </li>
              <li>
                Build the frontend bundle into <code className="font-mono text-purple-300">dist/</code>:{' '}
                <code className="font-mono text-purple-300">npm run build</code>
              </li>
              <li>
                Set <code className="font-mono text-purple-300">NODE_ENV=production</code> and{' '}
                <code className="font-mono text-purple-300">GEMINI_API_KEY</code> in your Cloud Run, Railway, Render, or VPS secret manager.
              </li>
              <li>
                Start the production server on port 3000:{' '}
                <code className="font-mono text-purple-300">npm start</code>
              </li>
            </ol>

            <div className="flex items-center gap-2 rounded-xl border border-purple-500/15 bg-[#0A0911] p-3 text-xs text-zinc-300">
              <Server className="h-4 w-4 shrink-0 text-purple-400" />
              <span>Always serve the app over HTTPS so Android wrappers and mobile downloads work reliably.</span>
            </div>
          </div>

          {/* Cloud Android APK Packaging Guide & Project ZIP */}
          <div className="space-y-4 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:p-6">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-600/20 text-purple-300">
                  <Smartphone className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-semibold text-white">Cloud Android APK Guide</h2>
                  <p className="text-xs text-zinc-400">Package ID: com.ayyaj.aistudio · No Android Studio needed</p>
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-purple-500/25 bg-[#161224] p-4 space-y-3">
              <div>
                <p className="text-xs font-semibold text-white">Download Complete Capacitor Project</p>
                <p className="mt-0.5 text-[11px] text-zinc-400">
                  Includes Android Gradle project, Capacitor config, GitHub Actions cloud APK workflow, and source code (excludes server secrets).
                </p>
              </div>
              <button
                type="button"
                disabled={isDownloadingZip}
                onClick={handleDownloadProjectZip}
                className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-purple-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-purple-500 disabled:opacity-60 transition-colors"
              >
                {isDownloadingZip ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    <span>Packaging Project ZIP...</span>
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4" />
                    <span>Download Complete Project ZIP</span>
                  </>
                )}
              </button>
            </div>

            <div className="space-y-2 text-xs leading-relaxed text-zinc-300">
              <p className="font-semibold text-white">Build Signed APK in the Cloud (GitHub Actions):</p>
              <ol className="list-decimal list-inside space-y-1.5">
                <li>Deploy your Node backend first so <code className="font-mono text-purple-300">GEMINI_API_KEY</code> stays on your server.</li>
                <li>Upload the downloaded ZIP contents to a GitHub repository.</li>
                <li>In GitHub Repo &rarr; Settings &rarr; Secrets &rarr; Actions, add <code className="font-mono text-purple-300">VITE_API_BASE_URL</code> (your HTTPS server URL) plus your keystore secrets (<code className="font-mono text-purple-300">ANDROID_KEYSTORE_BASE64</code>, <code className="font-mono text-purple-300">ANDROID_KEYSTORE_PASSWORD</code>, <code className="font-mono text-purple-300">ANDROID_KEY_ALIAS</code>, <code className="font-mono text-purple-300">ANDROID_KEY_PASSWORD</code>).</li>
                <li>Open the <strong>Actions</strong> tab &rarr; run <strong>Build Signed Android APK</strong> and download the signed <code className="font-mono text-purple-300">.apk</code> artifact.</li>
              </ol>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
