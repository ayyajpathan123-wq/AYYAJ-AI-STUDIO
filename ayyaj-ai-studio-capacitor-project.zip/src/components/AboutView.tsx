import { Cpu, Film, Image as ImageIcon, Shield, Smartphone } from 'lucide-react';
import type { AppTab } from '../types/studio';

interface AboutViewProps {
  onNavigate: (tab: AppTab) => void;
}

export function AboutView({ onNavigate }: AboutViewProps) {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-purple-500/20 bg-gradient-to-br from-[#141022] via-[#0D0B14] to-[#07060B] p-6 sm:p-8">
        <p className="text-xs font-medium tracking-wide text-purple-300">About the Studio</p>
        <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-white studio-wordmark-glow">
          AYYAJ AI STUDIO
        </h1>
        <p className="mt-3 max-w-2xl text-sm sm:text-base leading-relaxed text-zinc-300">
          AYYAJ AI STUDIO is a mobile-first generative media workspace built for fast, high-contrast image and video synthesis. Designed in obsidian black and deep amethyst tones, it keeps your creative workflow clean on Android phones, tablets, and desktop browsers.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => onNavigate('image')}
            className="min-h-[44px] rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-semibold text-white hover:bg-purple-500 transition-colors"
          >
            Open Image Studio
          </button>
          <button
            type="button"
            onClick={() => onNavigate('video')}
            className="min-h-[44px] rounded-xl border border-purple-500/30 bg-[#161324] px-5 py-2.5 text-xs font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
          >
            Open Video Studio
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5">
          <ImageIcon className="h-5 w-5 text-purple-400" />
          <h2 className="mt-3 font-display text-base font-semibold text-white">Precision Imagery</h2>
          <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
            Supports style direction, negative exclusions, and 1:1, 16:9, 9:16, and 4:5 aspect framing.
          </p>
        </div>

        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5">
          <Film className="h-5 w-5 text-purple-400" />
          <h2 className="mt-3 font-display text-base font-semibold text-white">Real Video Synthesis</h2>
          <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
            Text-to-video and image-to-video generation powered by Gemini Omni Flash with async progress tracking.
          </p>
        </div>

        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5">
          <Shield className="h-5 w-5 text-purple-400" />
          <h2 className="mt-3 font-display text-base font-semibold text-white">Server-Secured Keys</h2>
          <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
            All AI provider credentials live strictly on the Node/Express server via environment secrets.
          </p>
        </div>

        <div className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-5">
          <Smartphone className="h-5 w-5 text-purple-400" />
          <h2 className="mt-3 font-display text-base font-semibold text-white">Android Ready</h2>
          <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
            Thumb-zone bottom navigation, IndexedDB on-device gallery, Web App Manifest, and Capacitor APK guide.
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-2 rounded-2xl border border-purple-500/15 bg-[#100E19] p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Cpu className="h-5 w-5 text-purple-400 shrink-0" />
          <p className="text-xs text-zinc-300">
            Need to verify provider credentials or package an Android APK? Open the Setup &amp; Deployment guides in Settings.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className="min-h-[40px] shrink-0 rounded-xl border border-purple-500/30 px-4 py-2 text-xs font-semibold text-purple-200 hover:bg-purple-500/15 transition-colors"
        >
          Go to Settings
        </button>
      </div>
    </div>
  );
}
