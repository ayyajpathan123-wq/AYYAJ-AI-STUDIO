import { Clock, Trash2, X } from 'lucide-react';
import type { RecentPromptEntry } from '../utils/storage';

interface RecentPromptsSidebarProps {
  prompts: RecentPromptEntry[];
  activePrompt: string;
  onSelectPrompt: (text: string) => void;
  onRemovePrompt: (text: string) => void;
  onClearAll: () => void;
}

function formatShortTime(timestamp: number): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function RecentPromptsSidebar({
  prompts,
  activePrompt,
  onSelectPrompt,
  onRemovePrompt,
  onClearAll,
}: RecentPromptsSidebarProps) {
  const normalizedActive = activePrompt.trim();

  return (
    <aside
      aria-label="Recent Prompts"
      className="rounded-2xl border border-purple-500/15 bg-[#100E19] p-4 sm:p-5 flex flex-col"
    >
      <div className="flex items-center justify-between gap-2 pb-3 border-b border-purple-500/10">
        <div className="flex items-center gap-2 min-w-0">
          <Clock className="h-4 w-4 shrink-0 text-purple-400" />
          <h2 className="font-display text-sm font-semibold text-white truncate">
            Recent Prompts
          </h2>
          <span className="font-mono text-[11px] text-zinc-500 tabular-nums">
            {prompts.length}/10
          </span>
        </div>

        {prompts.length > 0 && (
          <button
            type="button"
            onClick={onClearAll}
            aria-label="Clear recent prompts"
            className="inline-flex min-h-[32px] items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-zinc-400 hover:bg-red-500/15 hover:text-red-300 transition-colors shrink-0"
          >
            <Trash2 className="h-3 w-3" />
            <span>Clear</span>
          </button>
        )}
      </div>

      {prompts.length === 0 ? (
        <div className="py-8 text-center">
          <p className="text-xs font-medium text-zinc-300">No recent prompts yet</p>
          <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">
            Your last 10 prompts appear here so you can reload and iterate with one tap.
          </p>
        </div>
      ) : (
        <ul className="mt-3 space-y-2 max-h-[420px] lg:max-h-[540px] overflow-y-auto pr-0.5">
          {prompts.map((entry) => {
            const isSelected = normalizedActive === entry.text;
            return (
              <li
                key={`${entry.text}-${entry.usedAt}`}
                className={`group flex items-stretch rounded-xl border transition-colors ${
                  isSelected
                    ? 'border-purple-500/60 bg-purple-600/15'
                    : 'border-purple-500/15 bg-[#0A0911] hover:border-purple-500/40'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectPrompt(entry.text)}
                  className="flex-1 min-w-0 px-3 py-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-purple-500 rounded-l-xl"
                >
                  <p className="line-clamp-2 text-xs leading-relaxed text-zinc-200 group-hover:text-white">
                    {entry.text}
                  </p>
                  <span className="mt-1 block font-mono text-[10px] text-zinc-500 tabular-nums">
                    {formatShortTime(entry.usedAt)}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onRemovePrompt(entry.text)}
                  aria-label="Remove prompt from history"
                  className="flex min-h-[44px] min-w-[36px] shrink-0 items-center justify-center rounded-r-xl text-zinc-500 hover:bg-red-500/15 hover:text-red-300 transition-colors"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </aside>
  );
}
