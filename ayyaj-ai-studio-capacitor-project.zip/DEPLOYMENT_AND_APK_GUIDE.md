# AYYAJ AI STUDIO — Cloud Android APK & Deployment Guide

## 1. Capacitor & Android Configuration (Pre-Configured)

- **App Name**: `AYYAJ AI STUDIO`
- **Android Package ID**: `com.ayyaj.aistudio`
- **Capacitor Config**: `capacitor.config.ts` (`webDir: 'dist'`, `androidScheme: 'https'`)
- **Android Native Project**: `android/` (generated via `@capacitor/android`)
- **Cloud Build Workflow**: `.github/workflows/build-android-apk.yml`

---

## 2. Step 1 — Deploy Your Backend Server (Keeps API Key Secure)

Before building the APK, deploy the Node/Express server so `GEMINI_API_KEY` stays strictly on the server:

```bash
npm install
npm run build
NODE_ENV=production GEMINI_API_KEY=your_server_api_key npm start
```

Deploy to Google Cloud Run, Render, Railway, or Fly.io and copy your HTTPS URL (e.g. `https://your-ayyaj-studio.run.app`).

---

## 3. Step 2 — Download Complete Project ZIP

Open **Settings → Deploy & Android APK** inside **AYYAJ AI STUDIO** and click **Download Complete Project ZIP** (or download from `/api/project/export`).

The ZIP contains:
- Complete React + Express source code
- Pre-configured `capacitor.config.ts` (`com.ayyaj.aistudio`)
- Complete `android/` Gradle project
- `.github/workflows/build-android-apk.yml` for zero-setup cloud APK builds
- `.env` secrets and `node_modules` are automatically excluded

---

## 4. Step 3 — Build a Signed Android APK in the Cloud (No Android Studio Needed)

### Option A: GitHub Actions (Free Cloud Build)

1. Create a new repository on **GitHub** and upload/push the extracted ZIP files.
2. Generate an Android signing keystore once in any cloud shell (or Linux/Mac/Windows terminal with Java):
   ```bash
   keytool -genkey -v -keystore release-keystore.jks \
     -keyalg RSA -keysize 2048 -validity 10000 -alias ayyaj-key
   base64 -w 0 release-keystore.jks > keystore_base64.txt
   ```
3. In your GitHub repo, open **Settings → Secrets and variables → Actions** and add:
   - `VITE_API_BASE_URL` — your deployed HTTPS backend URL (e.g. `https://your-ayyaj-studio.run.app`)
   - `ANDROID_KEYSTORE_BASE64` — contents of `keystore_base64.txt`
   - `ANDROID_KEYSTORE_PASSWORD` — your keystore password
   - `ANDROID_KEY_ALIAS` — `ayyaj-key`
   - `ANDROID_KEY_PASSWORD` — your key password
4. Open the **Actions** tab → select **Build Signed Android APK** → click **Run workflow**.
5. When finished (~2–3 minutes), download the **`ayyaj-ai-studio-signed-apk`** artifact from the workflow summary!

*(If you omit the keystore secrets, the workflow automatically produces an installable `ayyaj-ai-studio-debug-apk` so you can test right away.)*

### Option B: Codemagic or VoltBuilder

- **Codemagic**: Connect your GitHub repo, choose **Capacitor / Android**, set `VITE_API_BASE_URL`, upload your `.jks` keystore in Codemagic Code Signing, and start a release build to download the signed `.apk`.
- **VoltBuilder**: Upload the ZIP with a release keystore in VoltBuilder's web dashboard and download the signed `.apk`.
