package com.ayyaj.aistudio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
