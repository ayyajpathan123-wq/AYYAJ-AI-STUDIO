import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

const ALLOWED_IMAGE_RATIOS = new Set(['1:1', '16:9', '9:16', '4:5']);
const ALLOWED_VIDEO_RATIOS = new Set(['16:9', '9:16']);
const ALLOWED_VIDEO_DURATIONS = new Set(['3s', '5s', '8s', '10s', '15s']);
const ALLOWED_VIDEO_RESOLUTIONS = new Set(['720p', '1080p']);
const ALLOWED_IMAGE_MIMES = new Set(['image/png', 'image/jpeg', 'image/webp']);

const STYLE_MODIFIERS: Record<string, string> = {
  natural: '',
  cinematic: 'cinematic film still, dramatic atmospheric lighting, anamorphic lens depth, rich color grading',
  photorealistic: 'ultra-realistic editorial photography, sharp natural textures, authentic lighting, 85mm lens',
  '3d-render': 'high-precision 3D sculptural render, physically based materials, studio rim lighting, octane aesthetic',
  anime: 'refined modern anime key visual, crisp expressive linework, luminous cel shading, rich background art',
  'dark-editorial': 'moody obsidian and deep violet luxury studio aesthetic, dramatic chiaroscuro shadows, sculptural minimalism',
  'oil-painting': 'museum-grade oil painting on linen canvas, expressive brushwork, dramatic chiaroscuro lighting',
  'product-studio': 'commercial studio product photography, clean surface reflections, soft diffused key light',
};

interface VideoJob {
  id: string;
  status: 'processing' | 'completed' | 'failed';
  createdAt: number;
  updatedAt: number;
  videoDataUrl?: string;
  mimeType?: string;
  error?: string;
  code?: string;
}

const videoJobs = new Map<string, VideoJob>();

function pruneOldVideoJobs() {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [id, job] of videoJobs.entries()) {
    if (job.updatedAt < cutoff) {
      videoJobs.delete(id);
    }
  }
}

function getApiKey(): string {
  return (process.env.GEMINI_API_KEY || '').trim();
}

function isApiKeyConfigured(): boolean {
  const key = getApiKey();
  return Boolean(key && key !== 'MY_GEMINI_API_KEY' && key.length > 10);
}

function createGenAIClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: getApiKey(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function parseProviderError(err: unknown): { status: number; code: string; message: string } {
  const rawMessage = err instanceof Error ? err.message : String(err || 'Unknown provider error');
  const lower = rawMessage.toLowerCase();

  if (
    lower.includes('permission_denied') ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    lower.includes('403') ||
    lower.includes('401')
  ) {
    return {
      status: 403,
      code: 'API_KEY_INVALID',
      message:
        'API key rejected or lacks permission for this model. Select a valid billing-enabled Gemini API key in Settings > Secrets.',
    };
  }

  if (lower.includes('resource_exhausted') || lower.includes('429') || lower.includes('quota') || lower.includes('billing')) {
    return {
      status: 429,
      code: 'QUOTA_OR_BILLING_REQUIRED',
      message:
        'Quota limit reached or paid-tier billing required for this generation model. Upgrade or select a billing-enabled API key in Settings > Secrets.',
    };
  }

  if (lower.includes('not_found') || lower.includes('404')) {
    return {
      status: 404,
      code: 'MODEL_UNAVAILABLE',
      message: 'The requested generation model is unavailable for the current API configuration.',
    };
  }

  if (lower.includes('safety') || lower.includes('blocked')) {
    return {
      status: 422,
      code: 'CONTENT_BLOCKED',
      message: 'Generation was blocked by content safety filters. Please adjust your prompt and try again.',
    };
  }

  return {
    status: 500,
    code: 'GENERATION_FAILED',
    message: rawMessage.length > 260 ? `${rawMessage.slice(0, 260)}...` : rawMessage,
  };
}

const CAPACITOR_ORIGINS = new Set([
  'https://localhost',
  'http://localhost',
  'capacitor://localhost',
]);

const EXPORT_EXCLUDED_DIRS = new Set([
  'node_modules',
  '.git',
  'dist',
  '.gradle',
  'build',
  '.idea',
]);

function shouldExcludeExportPath(relPath: string): boolean {
  const normalized = relPath.replace(/\\/g, '/');
  const segments = normalized.split('/');
  if (segments.some((seg) => EXPORT_EXCLUDED_DIRS.has(seg))) {
    return true;
  }
  const base = path.basename(normalized);
  if (
    (base.startsWith('.env') && base !== '.env.example') ||
    base.endsWith('.jks') ||
    base.endsWith('.keystore') ||
    base === 'local.properties'
  ) {
    return true;
  }
  return false;
}

function collectProjectFiles(baseDir: string, currentDir: string, zip: JSZip) {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentDir, entry.name);
    const relPath = path.relative(baseDir, fullPath).replace(/\\/g, '/');
    if (!relPath || shouldExcludeExportPath(relPath)) continue;

    if (entry.isDirectory()) {
      collectProjectFiles(baseDir, fullPath, zip);
    } else if (entry.isFile()) {
      const content = fs.readFileSync(fullPath);
      zip.file(relPath, content);
    }
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '25mb' }));

  // Allow requests from Capacitor Android WebView origins without wildcard CORS
  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin;
    if (origin && CAPACITOR_ORIGINS.has(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    }
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  // Download complete Capacitor-ready project ZIP (excludes secrets & build artifacts)
  app.get('/api/project/export', async (_req: Request, res: Response) => {
    try {
      const rootDir = path.resolve(__dirname);
      const zip = new JSZip();
      collectProjectFiles(rootDir, rootDir, zip);

      const buffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="ayyaj-ai-studio-capacitor-project.zip"'
      );
      res.setHeader('Content-Length', String(buffer.length));
      res.send(buffer);
    } catch {
      res.status(500).json({
        code: 'EXPORT_FAILED',
        error: 'Unable to package project archive.',
      });
    }
  });

  // Health & Provider Status
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true, service: 'ayyaj-ai-studio' });
  });

  app.get('/api/status', (_req: Request, res: Response) => {
    const configured = isApiKeyConfigured();
    res.json({
      configured,
      provider: 'Google Gemini AI',
      imageModels: [
        { id: 'standard', model: 'gemini-3.1-flash-lite-image', label: 'Flash Image · Fast' },
        { id: 'high', model: 'gemini-nano-banana-2.1', label: 'Studio 2K · High Detail' },
      ],
      videoModel: { model: 'gemini-omni-1.2-flash', label: 'Omni Flash Video' },
      capabilities: {
        image: configured,
        video: configured,
      },
    });
  });

  // Real AI Image Generation Endpoint
  app.post('/api/image/generate', async (req: Request, res: Response) => {
    if (!isApiKeyConfigured()) {
      res.status(503).json({
        code: 'API_NOT_CONFIGURED',
        error: 'Server API key is not configured. Add GEMINI_API_KEY in Settings > Secrets to enable AI image generation.',
      });
      return;
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    const negativePrompt = typeof body.negativePrompt === 'string' ? body.negativePrompt.trim() : '';
    const style = typeof body.style === 'string' ? body.style.trim() : 'natural';
    const aspectRatio = typeof body.aspectRatio === 'string' ? body.aspectRatio.trim() : '1:1';
    const quality = body.quality === 'high' ? 'high' : 'standard';

    if (!prompt || prompt.length > 2000) {
      res.status(400).json({
        code: 'INVALID_PROMPT',
        error: 'Prompt is required and must be under 2,000 characters.',
      });
      return;
    }

    if (!ALLOWED_IMAGE_RATIOS.has(aspectRatio)) {
      res.status(400).json({
        code: 'INVALID_ASPECT_RATIO',
        error: 'Unsupported aspect ratio. Choose 1:1, 16:9, 9:16, or 4:5.',
      });
      return;
    }

    if (negativePrompt.length > 800) {
      res.status(400).json({
        code: 'INVALID_NEGATIVE_PROMPT',
        error: 'Negative prompt must be under 800 characters.',
      });
      return;
    }

    const styleDesc = STYLE_MODIFIERS[style] || '';
    const promptSegments = [prompt];
    if (styleDesc) {
      promptSegments.push(`Visual style: ${styleDesc}.`);
    }
    if (negativePrompt) {
      promptSegments.push(`Strictly exclude and avoid: ${negativePrompt}.`);
    }
    const finalPrompt = promptSegments.join(' ');

    // Map 4:5 to closest supported Gemini portrait aspect ratio (3:4); client crops to exact 4:5
    const apiAspectRatio = aspectRatio === '4:5' ? '3:4' : aspectRatio;
    const modelName = quality === 'high' ? 'gemini-nano-banana-2.1' : 'gemini-3.1-flash-lite-image';

    const startedAt = Date.now();
    try {
      const ai = createGenAIClient();
      const imageConfig: { aspectRatio: string; imageSize?: string } = {
        aspectRatio: apiAspectRatio,
      };
      if (quality === 'high') {
        imageConfig.imageSize = '2K';
      }

      const response = await ai.models.generateContent({
        model: modelName,
        contents: {
          parts: [{ text: finalPrompt }],
        },
        config: {
          imageConfig,
        },
      });

      let imageBase64 = '';
      let mimeType = 'image/png';
      let caption = '';

      for (const part of response.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data && !imageBase64) {
          imageBase64 = part.inlineData.data;
          mimeType = part.inlineData.mimeType || 'image/png';
        } else if (part.text) {
          caption += part.text;
        }
      }

      if (!imageBase64) {
        res.status(502).json({
          code: 'EMPTY_IMAGE_RESPONSE',
          error: caption || 'The AI model returned no image data. Please refine your prompt and try again.',
        });
        return;
      }

      res.json({
        imageDataUrl: `data:${mimeType};base64,${imageBase64}`,
        mimeType,
        model: modelName,
        requestedAspectRatio: aspectRatio,
        apiAspectRatio,
        durationMs: Date.now() - startedAt,
      });
    } catch (err) {
      const parsed = parseProviderError(err);
      res.status(parsed.status).json({
        code: parsed.code,
        error: parsed.message,
      });
    }
  });

  // Real AI Video Generation Endpoint (Background Job + Polling)
  app.post('/api/video/generate', async (req: Request, res: Response) => {
    if (!isApiKeyConfigured()) {
      res.status(503).json({
        code: 'API_NOT_CONFIGURED',
        error: 'Video generation requires a configured server-side GEMINI_API_KEY in Settings > Secrets.',
      });
      return;
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    const duration = typeof body.duration === 'string' ? body.duration.trim() : '5s';
    const aspectRatio = typeof body.aspectRatio === 'string' ? body.aspectRatio.trim() : '16:9';
    const resolution = typeof body.resolution === 'string' ? body.resolution.trim() : '720p';
    const refImg = body.referenceImage as { data?: unknown; mimeType?: unknown } | undefined;

    if (!prompt || prompt.length > 1500) {
      res.status(400).json({
        code: 'INVALID_PROMPT',
        error: 'Video prompt is required and must be under 1,500 characters.',
      });
      return;
    }

    if (!ALLOWED_VIDEO_DURATIONS.has(duration)) {
      res.status(400).json({
        code: 'INVALID_DURATION',
        error: 'Unsupported duration. Choose 3s, 5s, 8s, 10s, or 15s.',
      });
      return;
    }

    if (!ALLOWED_VIDEO_RATIOS.has(aspectRatio)) {
      res.status(400).json({
        code: 'INVALID_ASPECT_RATIO',
        error: 'Unsupported video aspect ratio. Choose 16:9 or 9:16.',
      });
      return;
    }

    if (!ALLOWED_VIDEO_RESOLUTIONS.has(resolution)) {
      res.status(400).json({
        code: 'INVALID_RESOLUTION',
        error: 'Unsupported resolution. Choose 720p or 1080p.',
      });
      return;
    }

    let validRefImage: { data: string; mimeType: string } | null = null;
    if (refImg && typeof refImg === 'object') {
      const data = typeof refImg.data === 'string' ? refImg.data.trim() : '';
      const mimeType = typeof refImg.mimeType === 'string' ? refImg.mimeType.trim() : '';
      if (!ALLOWED_IMAGE_MIMES.has(mimeType) || !data || data.length > 16_000_000) {
        res.status(400).json({
          code: 'INVALID_REFERENCE_IMAGE',
          error: 'Reference image must be PNG, JPEG, or WebP and under 12 MB.',
        });
        return;
      }
      validRefImage = { data, mimeType };
    }

    pruneOldVideoJobs();
    const jobId = crypto.randomUUID();
    const now = Date.now();
    const job: VideoJob = {
      id: jobId,
      status: 'processing',
      createdAt: now,
      updatedAt: now,
    };
    videoJobs.set(jobId, job);

    // Return 202 immediately and process video generation asynchronously
    res.status(202).json({
      jobId,
      status: job.status,
      createdAt: job.createdAt,
    });

    // Execute Gemini Interactions Omni Flash video call in background
    (async () => {
      try {
        const ai = createGenAIClient();
        const input = validRefImage
          ? [
              {
                type: 'image' as const,
                mime_type: validRefImage.mimeType,
                data: validRefImage.data,
              },
              {
                type: 'text' as const,
                text: prompt,
              },
            ]
          : prompt;

        const interaction = await ai.interactions.create(
          {
            model: 'gemini-omni-1.2-flash',
            input,
            background: false,
            store: false,
            stream: false,
            response_format: {
              type: 'video',
              aspect_ratio: aspectRatio as '16:9' | '9:16',
              duration,
              resolution,
            },
          } as Parameters<typeof ai.interactions.create>[0],
          { timeout: 300000 }
        );

        const videoPart = 'output_video' in interaction ? interaction.output_video : undefined;
        if (videoPart?.data) {
          const mime = videoPart.mime_type || 'video/mp4';
          job.status = 'completed';
          job.mimeType = mime;
          job.videoDataUrl = `data:${mime};base64,${videoPart.data}`;
          job.updatedAt = Date.now();
          return;
        }

        if (videoPart?.uri) {
          const parsedUrl = new URL(videoPart.uri);
          if (parsedUrl.protocol === 'https:' && parsedUrl.hostname.endsWith('.googleapis.com')) {
            const upstream = await fetch(videoPart.uri, {
              headers: { 'x-goog-api-key': getApiKey() },
            });
            if (upstream.ok) {
              const arrayBuf = await upstream.arrayBuffer();
              const mime = videoPart.mime_type || upstream.headers.get('content-type') || 'video/mp4';
              const base64 = Buffer.from(arrayBuf).toString('base64');
              job.status = 'completed';
              job.mimeType = mime;
              job.videoDataUrl = `data:${mime};base64,${base64}`;
              job.updatedAt = Date.now();
              return;
            }
          }
        }

        job.status = 'failed';
        job.code = 'EMPTY_VIDEO_RESPONSE';
        job.error = 'The AI video engine completed without returning video data.';
        job.updatedAt = Date.now();
      } catch (err) {
        const parsed = parseProviderError(err);
        job.status = 'failed';
        job.code = parsed.code;
        job.error = parsed.message;
        job.updatedAt = Date.now();
      }
    })();
  });

  app.get('/api/video/jobs/:jobId', (req: Request, res: Response) => {
    const jobId = String(req.params.jobId || '');
    const job = videoJobs.get(jobId);
    if (!job) {
      res.status(404).json({
        code: 'JOB_NOT_FOUND',
        error: 'Video generation job not found or expired.',
      });
      return;
    }

    res.json({
      jobId: job.id,
      status: job.status,
      elapsedMs: Date.now() - job.createdAt,
      videoDataUrl: job.status === 'completed' ? job.videoDataUrl : undefined,
      mimeType: job.mimeType,
      error: job.error,
      code: job.code,
    });
  });

  // Vite dev middleware or static production serving
  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build artifacts not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AYYAJ AI STUDIO server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start AYYAJ AI STUDIO server:', err);
  process.exit(1);
});
